clear all

%%%%%%%%% untargeted moments

%%%%%%%%% load initial common values

load SS_initial

CW_mu_initial=ca_mu;

MS1=ms1;

MS2=ms2;

MS3=ms3;

D1=d1;

D2=d2;

D3=d3;

N1=n1;

N2=n2;

N3=n3;

A_d_initial=(N1*D1+N2*D2+N3*D3)/(N1+N2+N3);

RW_d_initial=MS1*N1*D1+MS2*N2*D2+MS3*N3*D3;

A_p_initial=av_p;

RW_p_initial=wa_p;

HHI_initial=herfindal;

clearvars -except CW_mu_initial A_d_initial RW_d_initial A_p_initial RW_p_initial HHI_initial


%%%%%%%%%% load final High-Turbulence

load SS_final

CW_mu_HT=ca_mu;

MS1=ms1;

MS2=ms2;

MS3=ms3;

D1=d1;

D2=d2;

D3=d3;

N1=n1;

N2=n2;

N3=n3;

A_d_HT=(N1*D1+N2*D2+N3*D3)/(N1+N2+N3);

RW_d_HT=MS1*N1*D1+MS2*N2*D2+MS3*N3*D3;

A_p_HT=av_p;

RW_p_HT=wa_p;

HHI_HT=herfindal;

clearvars -except CW_mu_initial A_d_initial RW_d_initial A_p_initial RW_p_initial CW_mu_HT A_d_HT RW_d_HT A_p_HT RW_p_HT HHI_initial HHI_HT


%%%%%%%%%% load final Low-Turbulence

load SS_final_LT

CW_mu_LT=ca_mu;

MS1=ms1;

MS2=ms2;

MS3=ms3;

D1=d1;

D2=d2;

D3=d3;

N1=n1;

N2=n2;

N3=n3;

A_d_LT=(N1*D1+N2*D2+N3*D3)/(N1+N2+N3);

RW_d_LT=MS1*N1*D1+MS2*N2*D2+MS3*N3*D3;

A_p_LT=av_p;

RW_p_LT=wa_p;

HHI_LT=herfindal;

clearvars -except CW_mu_initial A_d_initial RW_d_initial A_p_initial RW_p_initial CW_mu_HT A_d_HT RW_d_HT A_p_HT RW_p_HT CW_mu_LT A_d_LT RW_d_LT A_p_LT RW_p_LT HHI_initial HHI_HT HHI_LT


%%%%%%% generate differences in percentage

Delta_mu_HT=100*(CW_mu_HT-CW_mu_initial)/CW_mu_initial;

Delta_mu_LT=100*(CW_mu_LT-CW_mu_initial)/CW_mu_initial;

% Delta_d_HT=100*(A_d_HT-A_d_initial)/A_d_initial;
% 
% Delta_d_LT=100*(A_d_LT-A_d_initial)/A_d_initial;

Delta_wd_HT=100*(RW_d_HT-RW_d_initial)/RW_d_initial;

Delta_wd_LT=100*(RW_d_LT-RW_d_initial)/RW_d_initial;

% Delta_p_HT=100*(A_p_HT-A_p_initial)/A_p_initial;
% 
% Delta_p_LT=100*(A_p_LT-A_p_initial)/A_p_initial;
% 
% Delta_wp_HT=100*(RW_p_HT-RW_p_initial)/RW_p_initial;
% 
% Delta_wp_LT=100*(RW_p_LT-RW_p_initial)/RW_p_initial;

Delta_HHI_HT=100*(HHI_HT-HHI_initial)/HHI_initial;

Delta_HHI_LT=100*(HHI_LT-HHI_initial)/HHI_initial;

clearvars -except Delta_d_HT Delta_d_LT Delta_wd_HT Delta_wd_LT Delta_p_HT Delta_p_LT Delta_wp_HT Delta_wp_LT Delta_mu_HT Delta_mu_LT Delta_HHI_HT Delta_HHI_LT

%% Ratio 

Ratio_Weighted_dividend=Delta_wd_HT/Delta_wd_LT;

Ratio_Cost_weighted_markup=Delta_mu_HT/Delta_mu_LT;

Ratio_Herfindal=Delta_HHI_HT/Delta_HHI_LT;

%clearvars -except Weighted_dividend Cost_weighted_markup Herfindal

save ratios_LR

