clear all

load HT_change_mu HT_change_mu
load LT_change_mu LT_change_mu

HT_mu=sort(HT_change_mu);
LT_mu=sort(LT_change_mu);

%remove outliers:

for i=1:100
    if LT_mu(i,1)<-1
        LT_mu(i,1)=NaN;
    end
    if LT_mu(i,1)>1
        LT_mu(i,1)=NaN;
    end
    
end

%remove outliers:

for i=1:100
    if HT_mu(i,1)<-1
        HT_mu(i,1)=NaN;
    end
    if HT_mu(i,1)>1
        HT_mu(i,1)=NaN;
    end
    
end

HT_var=var(HT_mu);
LT_var=var(LT_mu,"omitnan");
ratio_dispersion=HT_var/LT_var;


% figure(1)
% h1=histogram(HT_mu,10,'Normalization','probability');
% hold on
% h2=histogram(LT_mu,10,'Normalization','probability');
% legend('High-Turbulence','Low-Turbulence')
% savefig('mu_change.fig')

load HT_change_mu_RE HT_change_mu_RE
load LT_change_mu_RE LT_change_mu_RE
load HT_change_mu HT_change_mu
load LT_change_mu LT_change_mu

for i=1:100
    HT_ratio_RE(i,1)=HT_change_mu_RE(i,1)/HT_change_mu(i,1);
end

for i=1:100
    LT_ratio_RE(i,1)=LT_change_mu_RE(i,1)/LT_change_mu(i,1);
end

%remove outliers:

for i=1:100
    if LT_ratio_RE(i,1)<0
        LT_ratio_RE(i,1)=NaN;
    end
    if LT_ratio_RE(i,1)>1
        LT_ratio_RE(i,1)=NaN;
    end
    
end

%remove outliers:

for i=1:100
    if HT_ratio_RE(i,1)<0
        HT_ratio_RE(i,1)=NaN;
    end
    if HT_ratio_RE(i,1)>1
        HT_ratio_RE(i,1)=NaN;
    end
    
end

figure(2)
h3=histogram(HT_ratio_RE,10,'Normalization','probability');
hold on
h4=histogram(LT_ratio_RE,10,'Normalization','probability');
legend('High-Turbulence','Low-Turbulence')
%savefig('mu_change_RE.fig')