clear all

load HT 

periods_sim=120;

a=(WAMU(periods_sim,1)-WAMU(1,1))/WAMU(1,1);

b=(REAL(periods_sim,1)-REAL(1,1))/REAL(1,1);

c=(WTH(periods_sim,1)-WTH(1,1))/WTH(1,1);

d=(EE(periods_sim,1)-EE(1,1))/EE(1,1);

xh=[d c b a];

%%

load LT 

a=(WAMU(periods_sim,1)-WAMU(1,1))/WAMU(1,1);

b=(REAL(periods_sim,1)-REAL(1,1))/REAL(1,1);

c=(WTH(periods_sim,1)-WTH(1,1))/WTH(1,1);

d=(EE(periods_sim,1)-EE(1,1))/EE(1,1);

xh2=[d c b a];

%% plot

yh=[xh2 ; xh];

yh=yh*100;

h=barh(yh);

h(1).FaceColor = [1 1 0];

h(2).FaceColor = [0 1 0];

h(3).FaceColor = [1 0 0];

h(4).FaceColor = [0 0 1];
