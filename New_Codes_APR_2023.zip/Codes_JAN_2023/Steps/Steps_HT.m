clear all

%%% Steps

%%%% entry costs

load cali_new cali_new
load cali_old cali_old

periods_sim=121;

FE=zeros(periods_sim,1);

%%%%%%%%% Markov

Q11=zeros(periods_sim,1);
Q12=zeros(periods_sim,1);
Q13=zeros(periods_sim,1);
Q21=zeros(periods_sim,1);
Q22=zeros(periods_sim,1);
Q23=zeros(periods_sim,1);
Q31=zeros(periods_sim,1);
Q32=zeros(periods_sim,1);
Q33=zeros(periods_sim,1);

FE(1,1)=0.0572;
        
for i=2:101
    
    FE(i,1)=FE(i-1)+(0.1-0.0572)/100;
    
end

for i=102:periods_sim
    
    FE(i,1)=FE(i-1);
    
end


k=1;

for j=1:10:100
    
    for i=0:10
        
        Q11(j+i,1)=cali_old(1,4)+((cali_new(1,4)-cali_old(1,4))/10)*k;
        
    end
    
    k=k+1;
    
end

for i=102:periods_sim
    
    Q11(i,1)=Q11(i-1);
    
end

k=1;

for j=1:10:100
    
    for i=0:10
        
        Q21(j+i,1)=cali_old(1,7)+((cali_new(1,7)-cali_old(1,7))/10)*k;
        
    end
    
    k=k+1;
    
end

for i=102:periods_sim
    
    Q21(i,1)=Q21(i-1);
    
end

k=1;

for j=1:10:100
    
    for i=0:10
        
        Q31(j+i,1)=cali_old(1,10)+((cali_new(1,10)-cali_old(1,10))/10)*k;
        
    end
    
    k=k+1;
    
end

for i=102:periods_sim
    
    Q31(i,1)=Q31(i-1);
    
end

k=1;

for j=1:10:100
    
    for i=0:10
        
        Q22(j+i,1)=cali_old(1,8)+((cali_new(1,8)-cali_old(1,8))/10)*k;
        
    end
    
    k=k+1;
    
end

for i=102:periods_sim
    
    Q22(i,1)=Q22(i-1);
    
end

k=1;

for j=1:10:100
    
    for i=0:10
        
        Q33(j+i,1)=cali_old(1,12)+((cali_new(1,12)-cali_old(1,12))/10)*k;
        
    end
    
    k=k+1;
    
end

for i=102:periods_sim
    
    Q33(i,1)=Q33(i-1);
    
end

for z=1:periods_sim
    
    Q12(z,1)=1-Q11(z,1);
    
end

for z=1:periods_sim
    
    Q23(z,1)=1-Q21(z,1)-Q22(z,1);
    
end

for z=1:periods_sim
    
    Q32(z,1)=1-Q31(z,1)-Q33(z,1);
    
end

clear cali_new cali_old i j k z periods_sim;

save steps_HT.mat;




