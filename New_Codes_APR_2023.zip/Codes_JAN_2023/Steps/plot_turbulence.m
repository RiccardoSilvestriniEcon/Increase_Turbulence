clear all

load steps_HT

periods_sim=121;

Markov=zeros(3,3,periods_sim);

for i=1:periods_sim
   
    Markov(:,:,i)=[Q11(i,1) Q12(i,1) Q13(i,1); Q21(i,1) Q22(i,1) Q23(i,1); Q31(i,1) Q32(i,1) Q33(i,1)];
    
end

for k=1:periods_sim
    
    aux1(:,:,k)=Markov(:,:,k)^20;
    
    ac(k,1)=0.8*aux1(1,1,k)+0.19*aux1(2,2,k)+0.01*aux1(3,3,k);
    
end

turbulence_HT=1-ac;

entry_costs_HT=FE;

clearvars -except turbulence_HT entry_costs_HT periods_sim

load steps_LT

Markov=zeros(3,3,periods_sim);

for i=1:periods_sim
   
    Markov(:,:,i)=[Q11(i,1) Q12(i,1) Q13(i,1); Q21(i,1) Q22(i,1) Q23(i,1); Q31(i,1) Q32(i,1) Q33(i,1)];
    
end

for k=1:periods_sim
    
    aux1(:,:,k)=Markov(:,:,k)^20;
    
    ac(k,1)=0.8*aux1(1,1,k)+0.19*aux1(2,2,k)+0.01*aux1(3,3,k);
    
end

turbulence_LT=1-ac;

entry_costs_LT=FE;

clearvars -except turbulence_HT entry_costs_HT turbulence_LT entry_costs_LT

figure(1)

subplot(1,2,1)
plot(turbulence_HT)
hold on
plot(turbulence_LT,'k--')
title('Sectoral Turbulence')

subplot(1,2,2)
plot(entry_costs_HT)
hold on
plot(entry_costs_LT,'k--')
title('Entry Costs')

legend('High-Turbulence', 'Low-Turbulence')