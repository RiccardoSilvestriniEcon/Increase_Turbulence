clear all

%%%%%%%%%%%%%%%%%%%%%%%%%%% Calibration %%%%%%%%%%%%%%%%%%%%%%%%%

betta=0.99;   %%%%%%%%%%% Discount factor

theta=10;       %%%%%%%%%% elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%% low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

chi=cali_new(1,17);

omega1=cali_new(1,13);     %%%%%%%%%%%%%%%% prob entry (omega0 elsewhere)

omega2=cali_new(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_new(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_new(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

ddd1=1-delta1;

delta2=cali_new(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

ddd2=1-delta2;

delta3=cali_new(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

ddd3=1-delta3;

p12=cali_new(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_new(1,7);            %%%%%%%%% prob switch to 1

p23=cali_new(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_new(1,10);          %%%%%%%%% prob switch to 1

p32=cali_new(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

%%%% store median series

rep=100;

periods_sim=120;
periods_sim1=periods_sim+1;

median_CAMU=NaN(periods_sim,rep);
median_HHI=NaN(periods_sim,rep);
median_AMU=NaN(periods_sim,rep);
median_MU3=NaN(periods_sim,rep);
median_MU2=NaN(periods_sim,rep);
median_D3=NaN(periods_sim,rep);

for r=1:rep
    
    %%%%%%%%%%%%%%%%%%%% Initialize time series %%%%%%%%%%%%%%%%%%%%%%%%%

    N1=zeros(periods_sim1,1);
    N2=zeros(periods_sim1,1);
    N3=zeros(periods_sim1,1);
    Ne1=zeros(periods_sim,1);
    Ne2=zeros(periods_sim,1);
    Ne3=zeros(periods_sim,1);
    Nex1=zeros(periods_sim,1);
    Nex2=zeros(periods_sim,1);
    Nex3=zeros(periods_sim,1);
    D1=zeros(periods_sim,1);
    D2=zeros(periods_sim,1);
    D3=zeros(periods_sim,1);
    W=zeros(periods_sim,1);
    YY=zeros(periods_sim,1);
    C=zeros(periods_sim,1);
    L=zeros(periods_sim,1);
    MM=zeros(periods_sim,1);
    AMU=zeros(periods_sim,1);
    WAMU=zeros(periods_sim,1);
    CAMU=zeros(periods_sim,1);
    AP=zeros(periods_sim,1);
    WAP=zeros(periods_sim,1);
    HHI=zeros(periods_sim,1);
    RHO1=zeros(periods_sim,1);
    RHO2=zeros(periods_sim,1);
    RHO3=zeros(periods_sim,1);
    MU1=zeros(periods_sim,1);
    MU2=zeros(periods_sim,1);
    MU3=zeros(periods_sim,1);
    MS1=zeros(periods_sim,1);
    MS2=zeros(periods_sim,1);
    MS3=zeros(periods_sim,1);
    WTH=zeros(periods_sim,1);
    REAL=zeros(periods_sim,1);
    EE=zeros(periods_sim,1);

    %%%%%%%%%%%%%%%%%%%%% Starting values (from RSS_initial_x3 rounded from above)%%%%%%%%

    N1(1,1)=13;
    N2(1,1)=38;
    N3(1,1)=28; 


    %%%%%%%%%%%%%%%% The model

    %%%%%%%%%%%%% cycle with i for 1 to n periods

    %%%%%%%%%%%errors
    EEE=0;
    %%%%%%%%%%%%%

    for i=1:periods_sim
    
    %%%%%%%%%%% extract n_t(1), n_t(2) and n_t(3)
    
    n1=N1(i,1);
    
    n2=N2(i,1);
    
    n3=N3(i,1);
    
    if (n1==0) && (n2==0) && (n3==0)   %%%%%%restart 
        
        M=0;
    
    elseif (n1==0) && (n2>0) && (n3>0)
        
        k=1; 
        
        M=0; 
    
        while k>0
           
           fun=@equilibrium_n1;

           x0=[10,10,0,n2,n3,M,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10];
    
           lb=[0,0,0,n2,n3,M,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
   
           ub=[1000,1000,0,n2,n3,M,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000];

           x=lsqnonlin(fun,x0,lb,ub);

           e11=x(10);
    
           e22=x(16);
           
           e33=x(22);
           
           rho2=x(2);
        
           w=rho2*x2*((theta-1)/theta)*(1-rho2^(1-theta));
           
           %%%%%%%%%%%%% test if entry is profitable
    
           k=(1-omega2-omega3)*e11+omega2*e22+omega3*e33-fe*w;
    
           if k>0
               
               M=M+1;
               
           end
        
           if M>50
               
               k=-1;
               M=50;
               EEE=EEE+1;
        
           end
            
        end
        
    elseif (n2==0) && (n1>0) && (n3>0)
        
        k=1; 
        
        M=0; 
    
        while k>0
           
           fun=@equilibrium_n2;

           x0=[10,10,n1,0,n3,M,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10];
    
           lb=[0,0,n1,0,n3,M,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
   
           ub=[1000,1000,n1,0,n3,M,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000];

           x=lsqnonlin(fun,x0,lb,ub);

           e11=x(10);
    
           e22=x(16);
           
           e33=x(22);
           
           rho1=x(1);
        
           w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));
           
           %%%%%%%%%%%% test if entry is profitable
    
           k=(1-omega2-omega3)*e11+omega2*e22+omega3*e33-fe*w;
    
           if k>0
               
               M=M+1;
        
           end
        
           if M>50
               
               k=-1;
               M=50;
               EEE=EEE+1;
        
           end
            
         end
       
    elseif (n3==0) && (n1>0) && (n2>0)
         
        k=1; 
        
        M=0; 
    
        while k>0
           
           fun=@equilibrium_n3;

           x0=[10,10,n1,n2,0,M,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10];
    
           lb=[0,0,n1,n2,0,M,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
   
           ub=[1000,1000,n1,n2,0,M,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000];

           x=lsqnonlin(fun,x0,lb,ub);

           e11=x(10);
    
           e22=x(16);
           
           e33=x(22);
           
           rho1=x(1);
        
           w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));
    
           k=(1-omega2-omega3)*e11+omega2*e22+omega3*e33-fe*w;
    
           if k>0
               
               M=M+1;
        
           end
        
           if M>50
               
               k=-1;
               M=50;
               EEE=EEE+1;
        
           end
            
         end  
       
    elseif (n2>0) && (n1>0) && (n3>0)
        
        %%%%%%%%%%%% initialize first step with M=0
        
        k=1; 
        
        M=0; 
    
        while k>0
           
           fun=@equilibrium;

           x0=[10,10,n1,n2,n3,M,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10];
    
           lb=[0,0,n1,n2,n3,M,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
   
           ub=[1000,1000,n1,n2,n3,M,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000,1000];

           options = optimoptions(@lsqnonlin,'MaxFunctionEvaluations',100000,'StepTolerance',1e-18,'FunctionTolerance',1e-18,'MaxIterations',10000);

           x=lsqnonlin(fun,x0,lb,ub,options);

           e11=x(10);
    
           e22=x(16);
           
           e33=x(22);
           
           rho1=x(1);
        
           w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));
           
           %%%%%%%%%%%%%% check if entry is profitable
    
           k=(1-omega2-omega3)*e11+omega2*e22+omega3*e33-fe*w;
    
           if k>0
               
               M=M+1;
        
           end
           
           %%%%%%%%%%% stop if entry is exploding
        
           if M>50
               
               k=-1;
               M=50;
               EEE=EEE+1;
        
           end
            
        end
    
    end
    
    
    %%%%%%%%%%%%% with the cycle above I pin down potential entrants M
    
    MM(i,1)=M;
    
    %%%%%%% stochastic realization of entrants %%%%%%%%%%%

    pd1 = makedist('Binomial','N',M,'p',omega1);

    ne=random(pd1);

    pd2 = makedist('Multinomial','probabilities',[1-omega2-omega3 omega2 omega3]);

    test=random(pd2,1,ne);

    ne1=0;

    for z=1:ne
   
        if test(1,z)==1
        
        ne1=ne1+1;
        
        end
    
    end

    ne2=0;

    for z=1:ne
   
        if test(1,z)==2
        
        ne2=ne2+1;
        
        end
    
    end

    ne3=0;

    for z=1:ne
   
        if test(1,z)==3
        
        ne3=ne3+1;
        
        end
    
    end
    
    
    %%%%%%%%%%%%%%%%% given n_t^e(1) and n_t^e(2) and n_t^e(3) solve the CE %%%%%%
    
    if (n1==0) && (n2==0) && (n3==0)  %%%%%%%%%%%%%%% stop the program
        
        N1(i+1,1)=0;
        
        N2(i+1,1)=0;
        
        N3(i+1,1)=0;


    elseif (n1>0) && (n2>0) && (n3>0)
    
        fun=@solver_midrigan_lab;

        x0=[10,10,n1,n2,n3,ne1,ne2,ne3,10];
    
        lb=[0,0,n1,n2,n3,ne1,ne2,ne3,0];
   
        ub=[1000,1000,n1,n2,n3,ne1,ne2,ne3,1000];

        options = optimoptions(@lsqnonlin,'MaxFunctionEvaluations',100000,'StepTolerance',1e-18,'FunctionTolerance',1e-18,'MaxIterations',10000);

        x=lsqnonlin(fun,x0,lb,ub,options);


        rho1=x(1);
        
        rho2=x(2);
        
        rho3=((1-n1*rho1^(1-theta)-n2*rho2^(1-theta))/n3)^(1/(1-theta));

        c=x(9);

        w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));

        Y=c;
    
        d1=(1/theta-(1/theta-1)*rho1^(1-theta))*rho1^(1-theta)*Y;
    
        d2=(1/theta-(1/theta-1)*rho2^(1-theta))*rho2^(1-theta)*Y;
        
        d3=(1/theta-(1/theta-1)*rho3^(1-theta))*rho3^(1-theta)*Y;

        l=(w/(chi*c))^(phi);
        
        mu1=(((theta-1)/theta)*(1-rho1^(1-theta)))^(-1);
        
        mu2=(((theta-1)/theta)*(1-rho2^(1-theta)))^(-1);
        
        mu3=(((theta-1)/theta)*(1-rho3^(1-theta)))^(-1);
        
        averagemu=(n1*mu1+n2*mu2+n3*mu3)/(n1+n2+n3);

        l1=(rho1^(-theta)*Y)/x1;

        l2=(rho2^(-theta)*Y)/x2;

        l3=(rho3^(-theta)*Y)/x3;

        Lp=l1*n1+l2*n2+l3*n3;

        caveragemu=(mu1*n1*l1+mu2*n2*l2+mu3*n3*l3)/Lp;
        
        ms1=rho1^(1-theta);
        
        ms2=rho2^(1-theta);
        
        ms3=rho3^(1-theta);
        
        waveragemu=mu1*n1*ms1+mu2*n2*ms2+mu3*n3*ms3;
        
        H=n1*((ms1)^2)+n2*((ms2)^2)+n3*((ms3)^2);
        
        ap=(n1*x1+n2*x2+n3*x3)/(n1+n2+n3);
        
        wap=x1*n1*ms1+x2*n2*ms2+x3*n3*ms3;
    
    
        stock1=n1+ne1;

        stock2=n2+ne2;
        
        stock3=n3+ne3;

        pd3 = makedist('Binomial','N',stock1,'p',ddd1);

        n1s=random(pd3);

        pd4 = makedist('Binomial','N',stock2,'p',ddd2);

        n2s=random(pd4);
        
        pd5 = makedist('Binomial','N',stock3,'p',ddd3);

        n3s=random(pd5);
        
        pd6 = makedist('Multinomial','probabilities',[p11 p12 p13]);

        test1=random(pd6,1,n1s);

        n11=0;

        for z=1:n1s
   
            if test1(1,z)==1
        
            n11=n11+1;
        
            end
    
        end

        n12=0;

        for z=1:n1s
   
            if test1(1,z)==2
        
            n12=n12+1;
        
            end
    
        end

        n13=0;

        for z=1:n1s
   
            if test1(1,z)==3
        
            n13=n13+1;
        
            end
    
        end
        
        pd7 = makedist('Multinomial','probabilities',[p21 p22 p23]);

        test2=random(pd7,1,n2s);

        n21=0;

        for z=1:n2s
   
            if test2(1,z)==1
        
            n21=n21+1;
        
            end
    
        end

        n22=0;

        for z=1:n2s
   
            if test2(1,z)==2
        
            n22=n22+1;
        
            end
    
        end

        n23=0;

        for z=1:n2s
   
            if test2(1,z)==3
        
            n23=n23+1;
        
            end
    
        end        
        
        
        pd8 = makedist('Multinomial','probabilities',[p31 p32 p33]);

        test3=random(pd8,1,n3s);

        n31=0;

        for z=1:n3s
   
            if test3(1,z)==1
        
            n31=n31+1;
        
            end
    
        end

        n32=0;

        for z=1:n3s
   
            if test3(1,z)==2
        
            n32=n32+1;
        
            end
    
        end

        n33=0;

        for z=1:n3s
   
            if test3(1,z)==3
        
            n33=n33+1;
        
            end
    
        end        
        
        
        
        %%%%%%%%%%% incumbents tomorrow
        
        n111=n11+n21+n31;
        
        n222=n12+n22+n32;
        
        n333=n13+n23+n33;
        
        %%%%%%%%%%%%% save results
        
        Ne1(i,1)=ne1;
    
        Ne2(i,1)=ne2;
        
        Ne3(i,1)=ne3;
        
        Nex1(i,1)=stock1-n1s;
        
        Nex2(i,1)=stock2-n2s;
        
        Nex3(i,1)=stock3-n3s;
    
        N1(i+1,1)=n111;
    
        N2(i+1,1)=n222;
        
        N3(i+1,1)=n333;
    
        D1(i,1)=d1;
    
        D2(i,1)=d2;
        
        D3(i,1)=d3;
    
        W(i,1)=w;
    
        YY(i,1)=Y;
    
        C(i,1)=c;
    
        L(i,1)=l;
        
        AMU(i,1)=averagemu;
        
        WAMU(i,1)=waveragemu;
        
        CAMU(i,1)=caveragemu;
        
        AP(i,1)=ap;
        
        WAP(i,1)=wap;
        
        HHI(i,1)=H;
        
        RHO1(i,1)=rho1;
        
        RHO2(i,1)=rho2;
        
        RHO3(i,1)=rho3;
        
        MU1(i,1)=mu1;
        
        MU2(i,1)=mu2;
        
        MU3(i,1)=mu3;
        
        MS1(i,1)=ms1;
        
        MS2(i,1)=ms2;
        
        MS3(i,1)=ms3;        
    
    
    elseif (n1==0) && (n2>0) && (n3>0)
        
        fun=@solver_midrigan_lab_n1;

        x0=[10,10,0,n2,n3,ne1,ne2,ne3,10];
    
        lb=[0,0,0,n2,n3,ne1,ne2,ne3,0];
   
        ub=[1000,1000,0,n2,n3,ne1,ne2,ne3,1000];

        x=lsqnonlin(fun,x0,lb,ub);

        
        rho2=x(2);
        
        rho3=((1-n2*rho2^(1-theta))/n3)^(1/(1-theta));

        c=x(9);

        w=rho2*x2*((theta-1)/theta)*(1-rho2^(1-theta));

        Y=c;
    
        d1=0;
    
        d2=(1/theta-(1/theta-1)*rho2^(1-theta))*rho2^(1-theta)*Y;
        
        d3=(1/theta-(1/theta-1)*rho3^(1-theta))*rho3^(1-theta)*Y;

        l=(w/(chi*c))^(phi);
        
        mu1=theta/(theta-1);
        
        mu2=(((theta-1)/theta)*(1-rho2^(1-theta)))^(-1);
        
        mu3=(((theta-1)/theta)*(1-rho3^(1-theta)))^(-1);
        
        averagemu=(n1*mu1+n2*mu2+n3*mu3)/(n1+n2+n3);

        l1=0;

        l2=(rho2^(-theta)*Y)/x2;

        l3=(rho3^(-theta)*Y)/x3;

        Lp=l1*n1+l2*n2+l3*n3;

        caveragemu=(mu1*n1*l1+mu2*n2*l2+mu3*n3*l3)/Lp;
        
        ms1=0;
        
        ms2=rho2^(1-theta);
        
        ms3=rho3^(1-theta);
        
        waveragemu=mu1*n1*ms1+mu2*n2*ms2+mu3*n3*ms3;
        
        H=n1*((ms1)^2)+n2*((ms2)^2)+n3*((ms3)^2);
        
        ap=(n1*x1+n2*x2+n3*x3)/(n1+n2+n3);
        
        wap=x1*n1*ms1+x2*n2*ms2+x3*n3*ms3;
    
    
        stock1=n1+ne1;

        stock2=n2+ne2;
        
        stock3=n3+ne3;

        pd3 = makedist('Binomial','N',stock1,'p',ddd1);

        n1s=random(pd3);

        pd4 = makedist('Binomial','N',stock2,'p',ddd2);

        n2s=random(pd4);
        
        pd5 = makedist('Binomial','N',stock3,'p',ddd3);

        n3s=random(pd5);
        
        pd6 = makedist('Multinomial','probabilities',[p11 p12 p13]);

        test1=random(pd6,1,n1s);

        n11=0;

        for z=1:n1s
   
            if test1(1,z)==1
        
            n11=n11+1;
        
            end
    
        end

        n12=0;

        for z=1:n1s
   
            if test1(1,z)==2
        
            n12=n12+1;
        
            end
    
        end

        n13=0;

        for z=1:n1s
   
            if test1(1,z)==3
        
            n13=n13+1;
        
            end
    
        end
        
        pd7 = makedist('Multinomial','probabilities',[p21 p22 p23]);

        test2=random(pd7,1,n2s);

        n21=0;

        for z=1:n2s
   
            if test2(1,z)==1
        
            n21=n21+1;
        
            end
    
        end

        n22=0;

        for z=1:n2s
   
            if test2(1,z)==2
        
            n22=n22+1;
        
            end
    
        end

        n23=0;

        for z=1:n2s
   
            if test2(1,z)==3
        
            n23=n23+1;
        
            end
    
        end        
        
        
        pd8 = makedist('Multinomial','probabilities',[p31 p32 p33]);

        test3=random(pd8,1,n3s);

        n31=0;

        for z=1:n3s
   
            if test3(1,z)==1
        
            n31=n31+1;
        
            end
    
        end

        n32=0;

        for z=1:n3s
   
            if test3(1,z)==2
        
            n32=n32+1;
        
            end
    
        end

        n33=0;

        for z=1:n3s
   
            if test3(1,z)==3
        
            n33=n33+1;
        
            end
    
        end        
        

        
        n111=n11+n21+n31;
        
        n222=n12+n22+n32;
        
        n333=n13+n23+n33;
        
        Ne1(i,1)=ne1;
    
        Ne2(i,1)=ne2;
        
        Ne3(i,1)=ne3;
        
        Nex1(i,1)=stock1-n1s;
        
        Nex2(i,1)=stock2-n2s;
        
        Nex3(i,1)=stock3-n3s;
    
        N1(i+1,1)=n111;
    
        N2(i+1,1)=n222;
        
        N3(i+1,1)=n333;
    
        D1(i,1)=d1;
    
        D2(i,1)=d2;
        
        D3(i,1)=d3;
    
        W(i,1)=w;
    
        YY(i,1)=Y;
    
        C(i,1)=c;
    
        L(i,1)=l;
        
        AMU(i,1)=averagemu;
        
        WAMU(i,1)=waveragemu;
        
        CAMU(i,1)=caveragemu;
        
        AP(i,1)=ap;
        
        WAP(i,1)=wap;
        
        HHI(i,1)=H;
        
        RHO1(i,1)=RHO1(i-1,1);
        
        RHO2(i,1)=rho2;
        
        RHO3(i,1)=rho3;
        
        MU1(i,1)=mu1;
        
        MU2(i,1)=mu2;
        
        MU3(i,1)=mu3;
        
        MS1(i,1)=ms1;
        
        MS2(i,1)=ms2;
        
        MS3(i,1)=ms3;        
    
    
    elseif (n1>0) && (n2==0) && (n3>0)
        
        fun=@solver_midrigan_lab_n2;

        x0=[10,10,n1,0,n3,ne1,ne2,ne3,10];
    
        lb=[0,0,n1,0,n3,ne1,ne2,ne3,0];
   
        ub=[1000,1000,n1,0,n3,ne1,ne2,ne3,1000];

        x=lsqnonlin(fun,x0,lb,ub);


        rho1=x(1);
        
        rho3=((1-n1*rho1^(1-theta))/n3)^(1/(1-theta));

        c=x(9);

        w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));

        Y=c;
    
        d1=(1/theta-(1/theta-1)*rho1^(1-theta))*rho1^(1-theta)*Y;
    
        d2=0;
        
        d3=(1/theta-(1/theta-1)*rho3^(1-theta))*rho3^(1-theta)*Y;

        l=(w/(chi*c))^(phi);
        
        mu1=(((theta-1)/theta)*(1-rho1^(1-theta)))^(-1);
        
        mu2=theta/(theta-1);
        
        mu3=(((theta-1)/theta)*(1-rho3^(1-theta)))^(-1);
        
        averagemu=(n1*mu1+n2*mu2+n3*mu3)/(n1+n2+n3);
        
        ms1=rho1^(1-theta);
        
        ms2=0;
        
        ms3=rho3^(1-theta);
        
        H=n1*((ms1)^2)+n2*((ms2)^2)+n3*((ms3)^2);
        
        ap=(n1*x1+n2*x2+n3*x3)/(n1+n2+n3);
        
        wap=x1*n1*ms1+x2*n2*ms2+x3*n3*ms3;
    
    
        stock1=n1+ne1;

        stock2=n2+ne2;
        
        stock3=n3+ne3;

        pd3 = makedist('Binomial','N',stock1,'p',ddd1);

        n1s=random(pd3);

        pd4 = makedist('Binomial','N',stock2,'p',ddd2);

        n2s=random(pd4);
        
        pd5 = makedist('Binomial','N',stock3,'p',ddd3);

        n3s=random(pd5);
        
        pd6 = makedist('Multinomial','probabilities',[p11 p12 p13]);

        test1=random(pd6,1,n1s);

        n11=0;

        for z=1:n1s
   
            if test1(1,z)==1
        
            n11=n11+1;
        
            end
    
        end

        n12=0;

        for z=1:n1s
   
            if test1(1,z)==2
        
            n12=n12+1;
        
            end
    
        end

        n13=0;

        for z=1:n1s
   
            if test1(1,z)==3
        
            n13=n13+1;
        
            end
    
        end
        
        pd7 = makedist('Multinomial','probabilities',[p21 p22 p23]);

        test2=random(pd7,1,n2s);

        n21=0;

        for z=1:n2s
   
            if test2(1,z)==1
        
            n21=n21+1;
        
            end
    
        end

        n22=0;

        for z=1:n2s
   
            if test2(1,z)==2
        
            n22=n22+1;
        
            end
    
        end

        n23=0;

        for z=1:n2s
   
            if test2(1,z)==3
        
            n23=n23+1;
        
            end
    
        end        
        
        
        pd8 = makedist('Multinomial','probabilities',[p31 p32 p33]);

        test3=random(pd8,1,n3s);

        n31=0;

        for z=1:n3s
   
            if test3(1,z)==1
        
            n31=n31+1;
        
            end
    
        end

        n32=0;

        for z=1:n3s
   
            if test3(1,z)==2
        
            n32=n32+1;
        
            end
    
        end

        n33=0;

        for z=1:n3s
   
            if test3(1,z)==3
        
            n33=n33+1;
        
            end
    
        end        
        

        
        n111=n11+n21+n31;
        
        n222=n12+n22+n32;
        
        n333=n13+n23+n33;
        
        Ne1(i,1)=ne1;
    
        Ne2(i,1)=ne2;
        
        Ne3(i,1)=ne3;
        
        Nex1(i,1)=stock1-n1s;
        
        Nex2(i,1)=stock2-n2s;
        
        Nex3(i,1)=stock3-n3s;
    
        N1(i+1,1)=n111;
    
        N2(i+1,1)=n222;
        
        N3(i+1,1)=n333;
    
        D1(i,1)=d1;
    
        D2(i,1)=d2;
        
        D3(i,1)=d3;
    
        W(i,1)=w;
    
        YY(i,1)=Y;
    
        C(i,1)=c;
    
        L(i,1)=l;
        
        AMU(i,1)=averagemu;
        
        WAMU(i,1)=waveragemu;
        
        CAMU(i,1)=caveragemu;
        
        AP(i,1)=ap;
        
        WAP(i,1)=wap;
        
        HHI(i,1)=H;
        
        RHO1(i,1)=rho1;
        
        RHO2(i,1)=RHO2(i-1,1);
        
        RHO3(i,1)=rho3;
        
        MU1(i,1)=mu1;
        
        MU2(i,1)=mu2;
        
        MU3(i,1)=mu3;
        
        MS1(i,1)=ms1;
        
        MS2(i,1)=ms2;
        
        MS3(i,1)=ms3;        
        

    elseif (n1>0) && (n2>0) && (n3==0)
        
        fun=@solver_midrigan_lab_n3;

        x0=[10,10,n1,n2,0,ne1,ne2,ne3,10];
    
        lb=[0,0,n1,n2,0,ne1,ne2,ne3,0];
   
        ub=[1000,1000,n1,n2,0,ne1,ne2,ne3,1000];

        x=lsqnonlin(fun,x0,lb,ub);


        rho1=x(1);
        
        rho2=((1-n1*rho1^(1-theta))/n2)^(1/(1-theta));

        c=x(9);

        w=rho1*x1*((theta-1)/theta)*(1-rho1^(1-theta));

        Y=c;
    
        d1=(1/theta-(1/theta-1)*rho1^(1-theta))*rho1^(1-theta)*Y;
    
        d2=(1/theta-(1/theta-1)*rho2^(1-theta))*rho2^(1-theta)*Y;
        
        d3=0;

        l=(w/(chi*c))^(phi);
        
        mu1=(((theta-1)/theta)*(1-rho1^(1-theta)))^(-1);
        
        mu2=(((theta-1)/theta)*(1-rho2^(1-theta)))^(-1);
        
        mu3=theta/(theta-1);
        
        averagemu=(n1*mu1+n2*mu2+n3*mu3)/(n1+n2+n3);
        
        ms1=rho1^(1-theta);
        
        ms2=rho2^(1-theta);
        
        ms3=0;
        
        H=n1*((ms1)^2)+n2*((ms2)^2)+n3*((ms3)^2);
        
        ap=(n1*x1+n2*x2+n3*x3)/(n1+n2+n3);
        
        wap=x1*n1*ms1+x2*n2*ms2+x3*n3*ms3;
    
    
        stock1=n1+ne1;

        stock2=n2+ne2;
        
        stock3=n3+ne3;

        pd3 = makedist('Binomial','N',stock1,'p',ddd1);

        n1s=random(pd3);

        pd4 = makedist('Binomial','N',stock2,'p',ddd2);

        n2s=random(pd4);
        
        pd5 = makedist('Binomial','N',stock3,'p',ddd3);

        n3s=random(pd5);
        
        pd6 = makedist('Multinomial','probabilities',[p11 p12 p13]);

        test1=random(pd6,1,n1s);

        n11=0;

        for z=1:n1s
   
            if test1(1,z)==1
        
            n11=n11+1;
        
            end
    
        end

        n12=0;

        for z=1:n1s
   
            if test1(1,z)==2
        
            n12=n12+1;
        
            end
    
        end

        n13=0;

        for z=1:n1s
   
            if test1(1,z)==3
        
            n13=n13+1;
        
            end
    
        end
        
        pd7 = makedist('Multinomial','probabilities',[p21 p22 p23]);

        test2=random(pd7,1,n2s);

        n21=0;

        for z=1:n2s
   
            if test2(1,z)==1
        
            n21=n21+1;
        
            end
    
        end

        n22=0;

        for z=1:n2s
   
            if test2(1,z)==2
        
            n22=n22+1;
        
            end
    
        end

        n23=0;

        for z=1:n2s
   
            if test2(1,z)==3
        
            n23=n23+1;
        
            end
    
        end        
        
        
        pd8 = makedist('Multinomial','probabilities',[p31 p32 p33]);

        test3=random(pd8,1,n3s);

        n31=0;

        for z=1:n3s
   
            if test3(1,z)==1
        
            n31=n31+1;
        
            end
    
        end

        n32=0;

        for z=1:n3s
   
            if test3(1,z)==2
        
            n32=n32+1;
        
            end
    
        end

        n33=0;

        for z=1:n3s
   
            if test3(1,z)==3
        
            n33=n33+1;
        
            end
    
        end        
        

        
        n111=n11+n21+n31;
        
        n222=n12+n22+n32;
        
        n333=n13+n23+n33;
        
        Ne1(i,1)=ne1;
    
        Ne2(i,1)=ne2;
        
        Ne3(i,1)=ne3;
        
        Nex1(i,1)=stock1-n1s;
        
        Nex2(i,1)=stock2-n2s;
        
        Nex3(i,1)=stock3-n3s;
    
        N1(i+1,1)=n111;
    
        N2(i+1,1)=n222;
        
        N3(i+1,1)=n333;
    
        D1(i,1)=d1;
    
        D2(i,1)=d2;
        
        D3(i,1)=d3;
    
        W(i,1)=w;
    
        YY(i,1)=Y;
    
        C(i,1)=c;
    
        L(i,1)=l;
        
        AMU(i,1)=averagemu;
        
        AP(i,1)=ap;
        
        WAP(i,1)=wap;
        
        HHI(i,1)=H;
        
        RHO1(i,1)=rho1;
        
        RHO2(i,1)=rho2;
        
        RHO3(i,1)=RHO3(i-1,1);
        
        MU1(i,1)=mu1;
        
        MU2(i,1)=mu2;
        
        MU3(i,1)=mu3;       
        
        MS1(i,1)=ms1;
        
        MS2(i,1)=ms2;
        
        MS3(i,1)=ms3;        
        

    end
    
    end
    
    for j=1:periods_sim1
        
        NN(j,1)=N1(j,1)+N2(j,1)+N3(j,1);
        
    end
    
    %%%%%%%%%%%%%%%%%% Reallocation and composition weighted average markup 

    WTH(1,1)=WAMU(1,1);

    for i=2:periods_sim
    
        WTH(i,1)=WTH(i-1,1)+N1(i,1)*MS1(i-1,1)*theta/(theta-1)*(1/(1-MS1(i,1))-1/(1-MS1(i-1,1)))+N2(i,1)*MS2(i-1,1)*theta/(theta-1)*(1/(1-MS2(i,1))-1/(1-MS2(i-1,1)))+N3(i,1)*MS3(i-1,1)*theta/(theta-1)*(1/(1-MS3(i,1))-1/(1-MS3(i-1,1)));
    
    end

    REAL(1,1)=WAMU(1,1);

    for i=2:periods_sim
    
        REAL(i,1)=REAL(i-1,1)+N1(i,1)*(theta/(theta-1)*(1/(1-MS1(i-1,1)))-WAMU(i-1,1))*(MS1(i,1)-MS1(i-1,1))+N1(i,1)*theta/(theta-1)*(1/(1-MS1(i,1))-1/(1-MS1(i-1,1)))*(MS1(i,1)-MS1(i-1,1))+N2(i,1)*(theta/(theta-1)*(1/(1-MS2(i-1,1)))-WAMU(i-1,1))*(MS2(i,1)-MS2(i-1,1))+N2(i,1)*theta/(theta-1)*(1/(1-MS2(i,1))-1/(1-MS2(i-1,1)))*(MS2(i,1)-MS2(i-1,1))+N3(i,1)*(theta/(theta-1)*(1/(1-MS3(i-1,1)))-WAMU(i-1,1))*(MS3(i,1)-MS3(i-1,1))+N3(i,1)*theta/(theta-1)*(1/(1-MS3(i,1))-1/(1-MS3(i-1,1)))*(MS3(i,1)-MS3(i-1,1));
    
    end

    EE(1,1)=WAMU(1,1);

    for i=2:periods_sim
    
        EE(i,1)=EE(i-1,1)-Nex1(i-1,1)*MS1(i-1,1)*(theta/(theta-1)*(1/(1-MS1(i-1,1)))-WAMU(i-1,1))-Nex2(i-1,1)*MS2(i-1,1)*(theta/(theta-1)*(1/(1-MS2(i-1,1)))-WAMU(i-1,1))-Nex3(i-1,1)*MS3(i-1,1)*(theta/(theta-1)*(1/(1-MS3(i-1,1)))-WAMU(i-1,1));
    
    end
       
    %%%% store change in markup
    
    change_mu(r,1)=WAMU(periods_sim,1)-WAMU(1,1);
    change_mu_RE(r,1)=REAL(periods_sim,1)-REAL(1,1);
    change_mu_WH(r,1)=WTH(periods_sim,1)-WTH(1,1);
    change_mu_EE(r,1)=EE(periods_sim,1)-EE(1,1);
    
    
    %%%%%%%%%%%%%%%%%% Reallocation and composition simple average markup 

    COMPOSITION(1,1)=AMU(1,1);

    for i=2:periods_sim
    
        COMPOSITION(i,1)=COMPOSITION(i-1,1)+(N1(i,1)/NN(i,1)-N1(i-1,1)/NN(i-1,1))*MU1(i,1)+(N2(i,1)/NN(i,1)-N2(i-1,1)/NN(i-1,1))*MU2(i,1)+(N3(i,1)/NN(i,1)-N3(i-1,1)/NN(i-1,1))*MU3(i,1);
    
    end

    REALLOCATION(1,1)=AMU(1,1);

    for i=2:periods_sim
    
        REALLOCATION(i,1)=REALLOCATION(i-1,1)+N1(i-1,1)/NN(i-1,1)*(MU1(i,1)-MU1(i-1,1))+N2(i-1,1)/NN(i-1,1)*(MU2(i,1)-MU2(i-1,1))+N3(i-1,1)/NN(i-1,1)*(MU3(i,1)-MU3(i-1,1));
    
    end   
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%% store median
    
    for j=1:periods_sim
        median_CAMU(j,r)=CAMU(j,1);
        median_AMU(j,r)=AMU(j,1);
        median_HHI(j,r)=HHI(j,1);
        median_MU3(j,r)=MU3(j,1);
        median_MU2(j,r)=MU2(j,1);
        median_D3(j,r)=D3(j,1);
    end
    
end


HT_change_mu=change_mu;
HT_change_mu_RE=change_mu_RE;
HT_change_mu_WH=change_mu_WH;
HT_change_mu_EE=change_mu_EE;

save HT_change_mu HT_change_mu
save HT_change_mu_RE HT_change_mu_RE
save HT_change_mu_WH HT_change_mu_WH
save HT_change_mu_EE HT_change_mu_EE


%%

%%%%%%%%%%%%%%%%%%%%% create initial steady state from file %%%%%%%%%%%%%%%

load SS_initial

ISSD1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSD1(j,1)=d1;
end

ISSD2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSD2(j,1)=d2;
end

ISSD3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSD3(j,1)=d3;
end

ISSW=zeros(periods_sim,1);
for j=1:periods_sim
    ISSW(j,1)=w;
end

ISSYY=zeros(periods_sim,1);
for j=1:periods_sim
    ISSYY(j,1)=Y;
end

ISSAP=zeros(periods_sim,1);
for j=1:periods_sim
    ISSAP(j,1)=av_p;
end

ISSWAP=zeros(periods_sim,1);
for j=1:periods_sim
    ISSWAP(j,1)=wa_p;
end

ISSC=zeros(periods_sim,1);
for j=1:periods_sim
    ISSC(j,1)=c;
end

ISSL=zeros(periods_sim,1);
for j=1:periods_sim
    ISSL(j,1)=ll;
end

ISSAMU=zeros(periods_sim,1);
for j=1:periods_sim
    ISSAMU(j,1)=a_mu;
end

ISSCAMU=zeros(periods_sim,1);
for j=1:periods_sim
    ISSCAMU(j,1)=ca_mu;
end

ISSWAMU=zeros(periods_sim,1);
for j=1:periods_sim
    ISSWAMU(j,1)=wa_mu;
end

ISSHHI=zeros(periods_sim,1);
for j=1:periods_sim
    ISSHHI(j,1)=herfindal;
end

ISSN1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSN1(j,1)=n1;
end

ISSN2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSN2(j,1)=n2;
end

ISSN3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSN3(j,1)=n3;
end

ISSN=zeros(periods_sim,1);
for j=1:periods_sim
    ISSN(j,1)=ISSN1(j,1)+ISSN2(j,1)+ISSN3(j,1);
end

ISSRN1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRN1(j,1)=ISSN1(j,1)/ISSN(j,1);
end

ISSRN2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRN2(j,1)=ISSN2(j,1)/ISSN(j,1);
end

ISSRN3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRN3(j,1)=ISSN3(j,1)/ISSN(j,1);
end

ISSNE1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNE1(j,1)=ne1;
end

ISSNE2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNE2(j,1)=ne2;
end

ISSNE3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNE3(j,1)=ne3;
end

ISSNE=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNE(j,1)=ne;
end

ISSRNE1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNE1(j,1)=ISSNE1(j,1)/ISSN(j,1);
end

ISSRNE2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNE2(j,1)=ISSNE2(j,1)/ISSN(j,1);
end

ISSRNE3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNE3(j,1)=ISSNE3(j,1)/ISSN(j,1);
end

ISSRNE=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNE(j,1)=ISSNE(j,1)/ISSN(j,1);
end

ISSNEX1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNEX1(j,1)=nex1;
end

ISSNEX2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNEX2(j,1)=nex2;
end

ISSNEX3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNEX3(j,1)=nex3;
end

ISSNEX=zeros(periods_sim,1);
for j=1:periods_sim
    ISSNEX(j,1)=nex;
end

ISSRNEX1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNEX1(j,1)=ISSNEX1(j,1)/ISSN(j,1);
end

ISSRNET1=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNET1(j,1)=ISSRNE1(j,1)-ISSRNEX1(j,1);
end

ISSRNEX2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNEX2(j,1)=ISSNEX2(j,1)/ISSN(j,1);
end

ISSRNET2=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNET2(j,1)=ISSRNE2(j,1)-ISSRNEX2(j,1);
end

ISSRNEX3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNEX3(j,1)=ISSNEX3(j,1)/ISSN(j,1);
end

ISSRNET3=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNET3(j,1)=ISSRNE3(j,1)-ISSRNEX3(j,1);
end

ISSRNEX=zeros(periods_sim,1);
for j=1:periods_sim
    ISSRNEX(j,1)=ISSNEX(j,1)/ISSN(j,1);
end

ISSMM=zeros(periods_sim,1);
for j=1:periods_sim
    ISSMM(j,1)=M;
end

%%%%%%%%%%%%%%%%%%%%% create final steady state from file %%%%%%%%%%%%%%%

load SS_final

FSSD1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSD1(j,1)=d1;
end

FSSD2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSD2(j,1)=d2;
end

FSSD3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSD3(j,1)=d3;
end

FSSW=zeros(periods_sim,1);
for j=1:periods_sim
    FSSW(j,1)=w;
end

FSSYY=zeros(periods_sim,1);
for j=1:periods_sim
    FSSYY(j,1)=Y;
end

FSSAP=zeros(periods_sim,1);
for j=1:periods_sim
    FSSAP(j,1)=av_p;
end

FSSWAP=zeros(periods_sim,1);
for j=1:periods_sim
    FSSWAP(j,1)=wa_p;
end

FSSC=zeros(periods_sim,1);
for j=1:periods_sim
    FSSC(j,1)=c;
end

FSSL=zeros(periods_sim,1);
for j=1:periods_sim
    FSSL(j,1)=ll;
end

FSSAMU=zeros(periods_sim,1);
for j=1:periods_sim
    FSSAMU(j,1)=a_mu;
end

FSSCAMU=zeros(periods_sim,1);
for j=1:periods_sim
    FSSCAMU(j,1)=ca_mu;
end

FSSWAMU=zeros(periods_sim,1);
for j=1:periods_sim
    FSSWAMU(j,1)=wa_mu;
end

FSSHHI=zeros(periods_sim,1);
for j=1:periods_sim
    FSSHHI(j,1)=herfindal;
end

FSSN1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSN1(j,1)=n1;
end

FSSN2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSN2(j,1)=n2;
end

FSSN3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSN3(j,1)=n3;
end

FSSN=zeros(periods_sim,1);
for j=1:periods_sim
    FSSN(j,1)=FSSN1(j,1)+FSSN2(j,1)+FSSN3(j,1);
end

FSSRN1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRN1(j,1)=FSSN1(j,1)/FSSN(j,1);
end

FSSRN2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRN2(j,1)=FSSN2(j,1)/FSSN(j,1);
end

FSSRN3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRN3(j,1)=FSSN3(j,1)/FSSN(j,1);
end

FSSNE1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNE1(j,1)=ne1;
end

FSSNE2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNE2(j,1)=ne2;
end

FSSNE3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNE3(j,1)=ne3;
end

FSSNE=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNE(j,1)=ne;
end

FSSRNE1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNE1(j,1)=FSSNE1(j,1)/FSSN(j,1);
end

FSSRNE2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNE2(j,1)=FSSNE2(j,1)/FSSN(j,1);
end

FSSRNE3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNE3(j,1)=FSSNE3(j,1)/FSSN(j,1);
end

FSSRNE=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNE(j,1)=FSSNE(j,1)/FSSN(j,1);
end

FSSNEX1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNEX1(j,1)=nex1;
end

FSSNEX2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNEX2(j,1)=nex2;
end

FSSNEX3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNEX3(j,1)=nex3;
end

FSSNEX=zeros(periods_sim,1);
for j=1:periods_sim
    FSSNEX(j,1)=nex;
end

FSSRNEX1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNEX1(j,1)=FSSNEX1(j,1)/FSSN(j,1);
end

FSSRNEX2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNEX2(j,1)=FSSNEX2(j,1)/FSSN(j,1);
end

FSSRNEX3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNEX3(j,1)=FSSNEX3(j,1)/FSSN(j,1);
end

FSSRNET1=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNET1(j,1)=FSSRNE1(j,1)-FSSRNEX1(j,1);
end

FSSRNET2=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNET2(j,1)=FSSRNE2(j,1)-FSSRNEX2(j,1);
end

FSSRNET3=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNET3(j,1)=FSSRNE3(j,1)-FSSRNEX3(j,1);
end

FSSRNEX=zeros(periods_sim,1);
for j=1:periods_sim
    FSSRNEX(j,1)=FSSNEX(j,1)/FSSN(j,1);
end

FSSMM=zeros(periods_sim,1);
for j=1:periods_sim
    FSSMM(j,1)=M;
end


%% plot markups and HHI

%%%%%%%% generate median per series



%%%%%%% generate median per time

for j=1:periods_sim
    M2_AMU(j,1)=median(median_AMU(j,:));
    M2_CAMU(j,1)=median(median_CAMU(j,:));
    M2_HHI(j,1)=median(median_HHI(j,:));
    M2_MU3(j,1)=median(median_MU3(j,:));
    M2_MU2(j,1)=median(median_MU2(j,:));
    M2_D3(j,1)=median(median_D3(j,:));
end


figure(1)

ax=2;
by=2;

subplot(ax,by,1)
plot(M2_D3,'b')
title('Median cost-weighted Profits','fontsize',12)
hold on
plot(ISSD3,'r')
hold on
plot(FSSD3,'g')

subplot(ax,by,2)
plot(M2_CAMU,'b')
title('Median Cost-weighted Markup','fontsize',12)
hold on
plot(ISSCAMU,'r')
hold on
plot(FSSCAMU,'g')

subplot(ax,by,3)
plot(M2_MU2,'r')
title('Idiosyncratic Median Markups','fontsize',12)
hold on
plot(M2_MU3,'g')

subplot(ax,by,4)
plot(M2_HHI,'b')
title('Median Herfindal Index','fontsize',12)
hold on
plot(ISSHHI,'r')
hold on
plot(FSSHHI,'g')

savefig('economy_HT.fig')

%% plot markup decomposition

figure (3)

subplot(1,2,1)
plot(WAMU)
title('Decomposition Revenue-Weighted Average Markup','fontsize',12)
hold on
plot(WTH,'-.')
hold on 
plot(REAL,'--')
hold on
plot(EE,':')
legend('Average','Within','Reallocation','Net Entry')

subplot(1,2,2)
plot(AMU)
title('Decomposition Average Markup','fontsize',12)
hold on
plot(COMPOSITION,'-.')
hold on 
plot(REALLOCATION,'--')
legend('Average','Composition','Reallocation')

savefig('markup_HT.fig')

%% functions

%%%%%%%%%%%%% positive n1, n2, n3 (updated)

function F=solver_midrigan_lab(x)

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

phi=1/2;

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

ne1=x(6);

ne2=x(7);

ne3=x(8);

ne=ne1+ne2+ne3;


rho3=((1-n1*x(1)^(1-theta)-n2*x(2)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(9);

d2=(1/theta+((theta-1)/theta)*x(2)^(1-theta))*x(2)^(1-theta)*x(9);

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(9);

L=(w/(x(9)*chi))^(phi);


%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)*((theta-1)/theta)*(1-x(2)^(1-theta))-w/x2;

F(3)=x(9)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;


%%%%% given

F(4)=x(3)-x(3);

F(5)=x(4)-x(4);

F(6)=x(5)-x(5);

F(7)=x(6)-x(6);

F(8)=x(7)-x(7);

F(9)=x(8)-x(8);

end

%%%%%%%%%%%%%%%% n1==0 (updated)

function F=solver_midrigan_lab_n1(x)

theta=10;       %%%%%%%%%%elasticity intra sector

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

phi=1/2;

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

ne1=x(6);

ne2=x(7);

ne3=x(8);

ne=ne1+ne2+ne3;


rho3=((1-n2*x(2)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=0;

d2=(1/theta+((theta-1)/theta)*x(2)^(1-theta))*x(2)^(1-theta)*x(9);

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(9);

L=(w/(x(9)*chi))^(phi);


%%%%%%%%%%% solve

F(1)=x(1)-x(1);

F(2)=x(2)*((theta-1)/theta)*(1-x(2)^(1-theta))-w/x2;

F(3)=x(9)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;


%%%%% given

F(4)=x(3)-x(3);

F(5)=x(4)-x(4);

F(6)=x(5)-x(5);

F(7)=x(6)-x(6);

F(8)=x(7)-x(7);

F(9)=x(8)-x(8);

end

%%%%%%%%%%%%% n2==0 (updated)

function F=solver_midrigan_lab_n2(x)

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

phi=1/2;

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

ne1=x(6);

ne2=x(7);

ne3=x(8);

ne=ne1+ne2+ne3;


rho3=((1-n1*x(1)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(9);

d2=0;

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(9);

L=(w/(x(9)*chi))^(phi);


%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)-x(2);

F(3)=x(9)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;


%%%%% given

F(4)=x(3)-x(3);

F(5)=x(4)-x(4);

F(6)=x(5)-x(5);

F(7)=x(6)-x(6);

F(8)=x(7)-x(7);

F(9)=x(8)-x(8);

end

%%%%%%%%%%%%%%%% n3==0 (updated)

function F=solver_midrigan_lab_n3(x)

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

phi=1/2;

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

ne1=x(6);

ne2=x(7);

ne3=x(8);

ne=ne1+ne2+ne3;


rho2=((1-n1*x(1)^(1-theta))/n2)^(1/(1-theta));

w=rho2*x2*((theta-1)/theta)*(1-rho2^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(9);

d2=(1/theta+((theta-1)/theta)*rho2^(1-theta))*rho2^(1-theta)*x(9);

d3=0;

L=(w/(x(9)*chi))^(phi);


%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)-x(2);

F(3)=x(9)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;


%%%%% given

F(4)=x(3)-x(3);

F(5)=x(4)-x(4);

F(6)=x(5)-x(5);

F(7)=x(6)-x(6);

F(8)=x(7)-x(7);

F(9)=x(8)-x(8);

end

%%%%%%%%%%%%%%%%%%% functions to pin down potential entrants M

%%%%%%%%%%%%%%%%%%% positive n1, n2, n3 (updated)

function F=equilibrium(x)

betta=0.99;   %%%%%%%%%%%Discount factor

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

omega1=cali_new(1,13);     %%%%%%%%%%%%%%%% prob entry (omega0 elsewhere)

omega2=cali_new(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_new(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_new(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_new(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_new(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_new(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_new(1,7);            %%%%%%%%% prob switch to 1

p23=cali_new(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_new(1,10);          %%%%%%%%% prob switch to 1

p32=cali_new(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

chi=cali_new(1,17);



n1=x(3);

n2=x(4);

n3=x(5);

M=x(6);


ne=omega1*M;

ne2=omega2*ne;

ne3=omega3*ne;

ne1=ne-ne2-ne3;

rho3=((1-n1*x(1)^(1-theta)-n2*x(2)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(7);

d2=(1/theta+((theta-1)/theta)*x(2)^(1-theta))*x(2)^(1-theta)*x(7);

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(7);

L=(w/(x(7)*chi))^(phi);



%%%%% if entrant is type 1

n11p1=p11*(1-delta1)*(n1+ne1+1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3);

n22p1=p12*(1-delta1)*(n1+ne1+1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3);

n33p1=p13*(1-delta1)*(n1+ne1+1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3);

rho31=((1-n11p1*x(8)^(1-theta)-n22p1*x(9)^(1-theta))/n33p1)^(1/(1-theta));

d11=(1/theta+((theta-1)/theta)*x(8)^(1-theta))*x(8)^(1-theta)*x(7);

d21=(1/theta+((theta-1)/theta)*x(9)^(1-theta))*x(9)^(1-theta)*x(7);

d31=(1/theta+((theta-1)/theta)*rho31^(1-theta))*rho31^(1-theta)*x(7);


%%%%% if entrant is type 2

n11p2=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2+1)+p31*(1-delta3)*(n3+ne3);

n22p2=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2+1)+p32*(1-delta3)*(n3+ne3);

n33p2=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2+1)+p33*(1-delta3)*(n3+ne3);

rho32=((1-n11p2*x(13)^(1-theta)-n22p2*x(14)^(1-theta))/n33p2)^(1/(1-theta));

d12=(1/theta+((theta-1)/theta)*x(13)^(1-theta))*x(13)^(1-theta)*x(7);

d22=(1/theta+((theta-1)/theta)*x(14)^(1-theta))*x(14)^(1-theta)*x(7);

d32=(1/theta+((theta-1)/theta)*rho32^(1-theta))*rho32^(1-theta)*x(7);


%%%%% if entrant is type 3

n11p3=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3+1);

n22p3=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3+1);

n33p3=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3+1);

rho33=((1-n11p3*x(18)^(1-theta)-n22p3*x(19)^(1-theta))/n33p3)^(1/(1-theta));

d13=(1/theta+((theta-1)/theta)*x(18)^(1-theta))*x(18)^(1-theta)*x(7);

d23=(1/theta+((theta-1)/theta)*x(19)^(1-theta))*x(19)^(1-theta)*x(7);

d33=(1/theta+((theta-1)/theta)*rho33^(1-theta))*rho33^(1-theta)*x(7);


%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)*((theta-1)/theta)*(1-x(2)^(1-theta))-w/x2;

F(3)=x(7)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;

%%%%%%%%%% value today (x(10)) if entrant is type 1

F(4)=x(8)/rho31*(1-x(8)^(1-theta))/(1-rho31^(1-theta))-x3/x1;

F(5)=x(9)/rho31*(1-x(9)^(1-theta))/(1-rho31^(1-theta))-x3/x2;

F(6)=x(10)-betta*(1-delta1)*(p11*(x(10)+d11)+p12*(x(11)+d21)+p13*(x(12)+d31));

F(7)=x(11)-betta*(1-delta2)*(p21*(x(10)+d11)+p22*(x(11)+d21)+p23*(x(12)+d31));

F(8)=x(12)-betta*(1-delta3)*(p31*(x(10)+d11)+p32*(x(11)+d21)+p33*(x(12)+d31));

%%%%%%%%%% value today (x(16)) if entrant is type 2

F(9)=x(13)/rho32*(1-x(13)^(1-theta))/(1-rho32^(1-theta))-x3/x1;

F(10)=x(14)/rho32*(1-x(14)^(1-theta))/(1-rho32^(1-theta))-x3/x2;

F(11)=x(15)-betta*(1-delta1)*(p11*(x(15)+d12)+p12*(x(16)+d22)+p13*(x(17)+d32));

F(12)=x(16)-betta*(1-delta2)*(p21*(x(15)+d12)+p22*(x(16)+d22)+p23*(x(17)+d32));

F(13)=x(17)-betta*(1-delta3)*(p31*(x(15)+d12)+p32*(x(16)+d22)+p33*(x(17)+d32));

%%%%%%%%%% value today (x(22)) if entrant is type 3

F(14)=x(18)/rho33*(1-x(18)^(1-theta))/(1-rho33^(1-theta))-x3/x1;

F(15)=x(19)/rho33*(1-x(19)^(1-theta))/(1-rho33^(1-theta))-x3/x2;

F(16)=x(20)-betta*(1-delta1)*(p11*(x(20)+d13)+p12*(x(21)+d23)+p13*(x(22)+d33));

F(17)=x(21)-betta*(1-delta2)*(p21*(x(20)+d13)+p22*(x(21)+d23)+p23*(x(22)+d33));

F(18)=x(22)-betta*(1-delta3)*(p31*(x(20)+d13)+p32*(x(21)+d23)+p33*(x(22)+d33));

%%%%% given

F(19)=x(3)-x(3);

F(20)=x(4)-x(4);

F(21)=x(5)-x(5);

F(22)=x(6)-x(6);

end

%%%%%%%%%%%%%%%%%% n1==0 (updated)

function F=equilibrium_n1(x)

betta=0.99;   %%%%%%%%%%%Discount factor

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

omega1=cali_new(1,13);     %%%%%%%%%%%%%%%% prob entry (omega0 elsewhere)

omega2=cali_new(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_new(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_new(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_new(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_new(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_new(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_new(1,7);            %%%%%%%%% prob switch to 1

p23=cali_new(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_new(1,10);          %%%%%%%%% prob switch to 1

p32=cali_new(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

M=x(6);


ne=omega1*M;

ne2=omega2*ne;

ne3=omega3*ne;

ne1=ne-ne2-ne3;

rho3=((1-n2*x(2)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=0;

d2=(1/theta+((theta-1)/theta)*x(2)^(1-theta))*x(2)^(1-theta)*x(7);

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(7);

L=(w/(x(7)*chi))^(phi);



%%%%% if entrant is x(1)

n11p1=p11*(1-delta1)*(n1+ne1+1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3);

n22p1=p12*(1-delta1)*(n1+ne1+1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3);

n33p1=p13*(1-delta1)*(n1+ne1+1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3);

rho31=((1-n11p1*x(8)^(1-theta)-n22p1*x(9)^(1-theta))/n33p1)^(1/(1-theta));

d11=(1/theta+((theta-1)/theta)*x(8)^(1-theta))*x(8)^(1-theta)*x(7);

d21=(1/theta+((theta-1)/theta)*x(9)^(1-theta))*x(9)^(1-theta)*x(7);

d31=(1/theta+((theta-1)/theta)*rho31^(1-theta))*rho31^(1-theta)*x(7);


%%%%% if entrant is x(2)

n11p2=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2+1)+p31*(1-delta3)*(n3+ne3);

n22p2=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2+1)+p32*(1-delta3)*(n3+ne3);

n33p2=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2+1)+p33*(1-delta3)*(n3+ne3);

rho32=((1-n11p2*x(13)^(1-theta)-n22p2*x(14)^(1-theta))/n33p2)^(1/(1-theta));

d12=(1/theta+((theta-1)/theta)*x(13)^(1-theta))*x(13)^(1-theta)*x(7);

d22=(1/theta+((theta-1)/theta)*x(14)^(1-theta))*x(14)^(1-theta)*x(7);

d32=(1/theta+((theta-1)/theta)*rho32^(1-theta))*rho32^(1-theta)*x(7);


%%%%% if entrant is x(3)

n11p3=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3+1);

n22p3=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3+1);

n33p3=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3+1);

rho33=((1-n11p3*x(18)^(1-theta)-n22p3*x(19)^(1-theta))/n33p3)^(1/(1-theta));

d13=(1/theta+((theta-1)/theta)*x(18)^(1-theta))*x(18)^(1-theta)*x(7);

d23=(1/theta+((theta-1)/theta)*x(19)^(1-theta))*x(19)^(1-theta)*x(7);

d33=(1/theta+((theta-1)/theta)*rho33^(1-theta))*rho33^(1-theta)*x(7);


%%%%%%%%%%% solve

F(1)=x(1)-x(1);

F(2)=x(2)*((theta-1)/theta)*(1-x(2)^(1-theta))-w/x2;

F(3)=x(7)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;

%%%%%%%%%% if x(1)

F(4)=x(8)/rho31*(1-x(8)^(1-theta))/(1-rho31^(1-theta))-x3/x1;

F(5)=x(9)/rho31*(1-x(9)^(1-theta))/(1-rho31^(1-theta))-x3/x2;

F(6)=x(10)-betta*(1-delta1)*(p11*(x(10)+d11)+p12*(x(11)+d21)+p13*(x(12)+d31));

F(7)=x(11)-betta*(1-delta2)*(p21*(x(10)+d11)+p22*(x(11)+d21)+p23*(x(12)+d31));

F(8)=x(12)-betta*(1-delta3)*(p31*(x(10)+d11)+p32*(x(11)+d21)+p33*(x(12)+d31));

%%%%%%%%%% if x(2)

F(9)=x(13)/rho32*(1-x(13)^(1-theta))/(1-rho32^(1-theta))-x3/x1;

F(10)=x(14)/rho32*(1-x(14)^(1-theta))/(1-rho32^(1-theta))-x3/x2;

F(11)=x(15)-betta*(1-delta1)*(p11*(x(15)+d12)+p12*(x(16)+d22)+p13*(x(17)+d32));

F(12)=x(16)-betta*(1-delta2)*(p21*(x(15)+d12)+p22*(x(16)+d22)+p23*(x(17)+d32));

F(13)=x(17)-betta*(1-delta3)*(p31*(x(15)+d12)+p32*(x(16)+d22)+p33*(x(17)+d32));

%%%%%%%%%% if x(3)

F(14)=x(18)/rho33*(1-x(18)^(1-theta))/(1-rho33^(1-theta))-x3/x1;

F(15)=x(19)/rho33*(1-x(19)^(1-theta))/(1-rho33^(1-theta))-x3/x2;

F(16)=x(20)-betta*(1-delta1)*(p11*(x(20)+d13)+p12*(x(21)+d23)+p13*(x(22)+d33));

F(17)=x(21)-betta*(1-delta2)*(p21*(x(20)+d13)+p22*(x(21)+d23)+p23*(x(22)+d33));

F(18)=x(22)-betta*(1-delta3)*(p31*(x(20)+d13)+p32*(x(21)+d23)+p33*(x(22)+d33));

%%%%% given

F(19)=x(3)-x(3);

F(20)=x(4)-x(4);

F(21)=x(5)-x(5);

F(22)=x(6)-x(6);

end

%%%%%%%%%%%%%%%%%% n2==0 (updated)

function F=equilibrium_n2(x)

betta=0.99;   %%%%%%%%%%%Discount factor

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

omega1=cali_new(1,13);     %%%%%%%%%%%%%%%% prob entry (omega0 elsewhere)

omega2=cali_new(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_new(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_new(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_new(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_new(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_new(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_new(1,7);            %%%%%%%%% prob switch to 1

p23=cali_new(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_new(1,10);          %%%%%%%%% prob switch to 1

p32=cali_new(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

M=x(6);


ne=omega1*M;

ne2=omega2*ne;

ne3=omega3*ne;

ne1=ne-ne2-ne3;

rho3=((1-n1*x(1)^(1-theta))/n3)^(1/(1-theta));

w=rho3*x3*((theta-1)/theta)*(1-rho3^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(7);

d2=0;

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(7);

L=(w/(x(7)*chi))^(phi);


%%%%% if entrant is x(1)

n11p1=p11*(1-delta1)*(n1+ne1+1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3);

n22p1=p12*(1-delta1)*(n1+ne1+1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3);

n33p1=p13*(1-delta1)*(n1+ne1+1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3);

rho31=((1-n11p1*x(8)^(1-theta)-n22p1*x(9)^(1-theta))/n33p1)^(1/(1-theta));

d11=(1/theta+((theta-1)/theta)*x(8)^(1-theta))*x(8)^(1-theta)*x(7);

d21=(1/theta+((theta-1)/theta)*x(9)^(1-theta))*x(9)^(1-theta)*x(7);

d31=(1/theta+((theta-1)/theta)*rho31^(1-theta))*rho31^(1-theta)*x(7);


%%%%% if entrant is x(2)

n11p2=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2+1)+p31*(1-delta3)*(n3+ne3);

n22p2=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2+1)+p32*(1-delta3)*(n3+ne3);

n33p2=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2+1)+p33*(1-delta3)*(n3+ne3);

rho32=((1-n11p2*x(13)^(1-theta)-n22p2*x(14)^(1-theta))/n33p2)^(1/(1-theta));

d12=(1/theta+((theta-1)/theta)*x(13)^(1-theta))*x(13)^(1-theta)*x(7);

d22=(1/theta+((theta-1)/theta)*x(14)^(1-theta))*x(14)^(1-theta)*x(7);

d32=(1/theta+((theta-1)/theta)*rho32^(1-theta))*rho32^(1-theta)*x(7);


%%%%% if entrant is x(3)

n11p3=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3+1);

n22p3=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3+1);

n33p3=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3+1);

rho33=((1-n11p3*x(18)^(1-theta)-n22p3*x(19)^(1-theta))/n33p3)^(1/(1-theta));

d13=(1/theta+((theta-1)/theta)*x(18)^(1-theta))*x(18)^(1-theta)*x(7);

d23=(1/theta+((theta-1)/theta)*x(19)^(1-theta))*x(19)^(1-theta)*x(7);

d33=(1/theta+((theta-1)/theta)*rho33^(1-theta))*rho33^(1-theta)*x(7);


%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)-x(2);

F(3)=x(7)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;

%%%%%%%%%% if x(1)

F(4)=x(8)/rho31*(1-x(8)^(1-theta))/(1-rho31^(1-theta))-x3/x1;

F(5)=x(9)/rho31*(1-x(9)^(1-theta))/(1-rho31^(1-theta))-x3/x2;

F(6)=x(10)-betta*(1-delta1)*(p11*(x(10)+d11)+p12*(x(11)+d21)+p13*(x(12)+d31));

F(7)=x(11)-betta*(1-delta2)*(p21*(x(10)+d11)+p22*(x(11)+d21)+p23*(x(12)+d31));

F(8)=x(12)-betta*(1-delta3)*(p31*(x(10)+d11)+p32*(x(11)+d21)+p33*(x(12)+d31));

%%%%%%%%%% if x(2)

F(9)=x(13)/rho32*(1-x(13)^(1-theta))/(1-rho32^(1-theta))-x3/x1;

F(10)=x(14)/rho32*(1-x(14)^(1-theta))/(1-rho32^(1-theta))-x3/x2;

F(11)=x(15)-betta*(1-delta1)*(p11*(x(15)+d12)+p12*(x(16)+d22)+p13*(x(17)+d32));

F(12)=x(16)-betta*(1-delta2)*(p21*(x(15)+d12)+p22*(x(16)+d22)+p23*(x(17)+d32));

F(13)=x(17)-betta*(1-delta3)*(p31*(x(15)+d12)+p32*(x(16)+d22)+p33*(x(17)+d32));

%%%%%%%%%% if x(3)

F(14)=x(18)/rho33*(1-x(18)^(1-theta))/(1-rho33^(1-theta))-x3/x1;

F(15)=x(19)/rho33*(1-x(19)^(1-theta))/(1-rho33^(1-theta))-x3/x2;

F(16)=x(20)-betta*(1-delta1)*(p11*(x(20)+d13)+p12*(x(21)+d23)+p13*(x(22)+d33));

F(17)=x(21)-betta*(1-delta2)*(p21*(x(20)+d13)+p22*(x(21)+d23)+p23*(x(22)+d33));

F(18)=x(22)-betta*(1-delta3)*(p31*(x(20)+d13)+p32*(x(21)+d23)+p33*(x(22)+d33));

%%%%% given

F(19)=x(3)-x(3);

F(20)=x(4)-x(4);

F(21)=x(5)-x(5);

F(22)=x(6)-x(6);

end

%%%%%%%%%%%%%%%%%%%%%%% if n3==0 (updated)

function F=equilibrium_n3(x)

betta=0.99;   %%%%%%%%%%%Discount factor

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

load cali_new cali_new

fe=cali_new(1,16);         %%%%%%%%%%%%%%%%entry costs

omega1=cali_new(1,13);     %%%%%%%%%%%%%%%% prob entry (omega0 elsewhere)

omega2=cali_new(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_new(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_new(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_new(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_new(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_new(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_new(1,7);            %%%%%%%%% prob switch to 1

p23=cali_new(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_new(1,10);          %%%%%%%%% prob switch to 1

p32=cali_new(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

chi=cali_new(1,17);


n1=x(3);

n2=x(4);

n3=x(5);

M=x(6);


ne=omega1*M;

ne2=omega2*ne;

ne3=omega3*ne;

ne1=ne-ne2-ne3;

rho2=((1-n1*x(1)^(1-theta))/n2)^(1/(1-theta));

w=rho2*x2*((theta-1)/theta)*(1-rho2^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(7);

d2=(1/theta+((theta-1)/theta)*rho2^(1-theta))*rho2^(1-theta)*x(7);

d3=0;

L=(w/(x(7)*chi))^(phi);



%%%%% if entrant is x(1)

n11p1=p11*(1-delta1)*(n1+ne1+1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3);

n22p1=p12*(1-delta1)*(n1+ne1+1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3);

n33p1=p13*(1-delta1)*(n1+ne1+1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3);

rho31=((1-n11p1*x(8)^(1-theta)-n22p1*x(9)^(1-theta))/n33p1)^(1/(1-theta));

d11=(1/theta+((theta-1)/theta)*x(8)^(1-theta))*x(8)^(1-theta)*x(7);

d21=(1/theta+((theta-1)/theta)*x(9)^(1-theta))*x(9)^(1-theta)*x(7);

d31=(1/theta+((theta-1)/theta)*rho31^(1-theta))*rho31^(1-theta)*x(7);


%%%%% if entrant is x(2)

n11p2=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2+1)+p31*(1-delta3)*(n3+ne3);

n22p2=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2+1)+p32*(1-delta3)*(n3+ne3);

n33p2=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2+1)+p33*(1-delta3)*(n3+ne3);

rho32=((1-n11p2*x(13)^(1-theta)-n22p2*x(14)^(1-theta))/n33p2)^(1/(1-theta));

d12=(1/theta+((theta-1)/theta)*x(13)^(1-theta))*x(13)^(1-theta)*x(7);

d22=(1/theta+((theta-1)/theta)*x(14)^(1-theta))*x(14)^(1-theta)*x(7);

d32=(1/theta+((theta-1)/theta)*rho32^(1-theta))*rho32^(1-theta)*x(7);


%%%%% if entrant is x(3)

n11p3=p11*(1-delta1)*(n1+ne1)+p21*(1-delta2)*(n2+ne2)+p31*(1-delta3)*(n3+ne3+1);

n22p3=p12*(1-delta1)*(n1+ne1)+p22*(1-delta2)*(n2+ne2)+p32*(1-delta3)*(n3+ne3+1);

n33p3=p13*(1-delta1)*(n1+ne1)+p23*(1-delta2)*(n2+ne2)+p33*(1-delta3)*(n3+ne3+1);

rho33=((1-n11p3*x(18)^(1-theta)-n22p3*x(19)^(1-theta))/n33p3)^(1/(1-theta));

d13=(1/theta+((theta-1)/theta)*x(18)^(1-theta))*x(18)^(1-theta)*x(7);

d23=(1/theta+((theta-1)/theta)*x(19)^(1-theta))*x(19)^(1-theta)*x(7);

d33=(1/theta+((theta-1)/theta)*rho33^(1-theta))*rho33^(1-theta)*x(7);




%%%%%%%%%%% solve

F(1)=x(1)*((theta-1)/theta)*(1-x(1)^(1-theta))-w/x1;

F(2)=x(2)-x(2);

F(3)=x(7)+ne*w*fe-w*L-n1*d1-n2*d2-n3*d3;

%%%%%%%%%% if x(1)

F(4)=x(8)/rho31*(1-x(8)^(1-theta))/(1-rho31^(1-theta))-x3/x1;

F(5)=x(9)/rho31*(1-x(9)^(1-theta))/(1-rho31^(1-theta))-x3/x2;

F(6)=x(10)-betta*(1-delta1)*(p11*(x(10)+d11)+p12*(x(11)+d21)+p13*(x(12)+d31));

F(7)=x(11)-betta*(1-delta2)*(p21*(x(10)+d11)+p22*(x(11)+d21)+p23*(x(12)+d31));

F(8)=x(12)-betta*(1-delta3)*(p31*(x(10)+d11)+p32*(x(11)+d21)+p33*(x(12)+d31));

%%%%%%%%%% if x(2)

F(9)=x(13)/rho32*(1-x(13)^(1-theta))/(1-rho32^(1-theta))-x3/x1;

F(10)=x(14)/rho32*(1-x(14)^(1-theta))/(1-rho32^(1-theta))-x3/x2;

F(11)=x(15)-betta*(1-delta1)*(p11*(x(15)+d12)+p12*(x(16)+d22)+p13*(x(17)+d32));

F(12)=x(16)-betta*(1-delta2)*(p21*(x(15)+d12)+p22*(x(16)+d22)+p23*(x(17)+d32));

F(13)=x(17)-betta*(1-delta3)*(p31*(x(15)+d12)+p32*(x(16)+d22)+p33*(x(17)+d32));

%%%%%%%%%% if x(3)

F(14)=x(18)/rho33*(1-x(18)^(1-theta))/(1-rho33^(1-theta))-x3/x1;

F(15)=x(19)/rho33*(1-x(19)^(1-theta))/(1-rho33^(1-theta))-x3/x2;

F(16)=x(20)-betta*(1-delta1)*(p11*(x(20)+d13)+p12*(x(21)+d23)+p13*(x(22)+d33));

F(17)=x(21)-betta*(1-delta2)*(p21*(x(20)+d13)+p22*(x(21)+d23)+p23*(x(22)+d33));

F(18)=x(22)-betta*(1-delta3)*(p31*(x(20)+d13)+p32*(x(21)+d23)+p33*(x(22)+d33));

%%%%% given

F(19)=x(3)-x(3);

F(20)=x(4)-x(4);

F(21)=x(5)-x(5);

F(22)=x(6)-x(6);

end

