cd 'C:\Users\rsilv\Desktop\MS (2022b)\Codes_JAN_2023\Median_transition\Merge'

%% gen final FIG

a1=hgload('MU_HT.fig');
a2=hgload('MU_LT.fig');
b1=hgload('CMU_HT.fig');
b2=hgload('CMU_LT.fig');
c1=hgload('iMU_HT.fig');
c2=hgload('iMU_LT.fig');
d1=hgload('HHI_HT.fig');
d2=hgload('HHI_LT.fig');
% Prepare subplots
figure
h(1)=subplot(4,2,1);
h(2)=subplot(4,2,3);
h(3)=subplot(4,2,2);
h(4)=subplot(4,2,4);
h(5)=subplot(4,2,5);
h(6)=subplot(4,2,7);
h(7)=subplot(4,2,6);
h(8)=subplot(4,2,8);
% Paste figures on the subplots
copyobj(allchild(get(a1,'CurrentAxes')),h(1));
copyobj(allchild(get(b1,'CurrentAxes')),h(3));
copyobj(allchild(get(c1,'CurrentAxes')),h(5));
copyobj(allchild(get(d1,'CurrentAxes')),h(7));
copyobj(allchild(get(a2,'CurrentAxes')),h(2));
copyobj(allchild(get(b2,'CurrentAxes')),h(4));
copyobj(allchild(get(c2,'CurrentAxes')),h(6));
copyobj(allchild(get(d2,'CurrentAxes')),h(8));
savefig('benchmark.fig');