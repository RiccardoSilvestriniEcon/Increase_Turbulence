%cd 'C:\Users\agama\Dropbox\Turbulence Trends\Codes_SEP2022'\Heterofe_OK\Figures\
k=hgload('Figure_7b.fig');
c=hgload('av_change_mu.fig');
% Prepare subplots
figure
h(1)=subplot(1,2,1);
h(2)=subplot(1,2,2);
% Paste figures on the subplots
copyobj(allchild(get(c,'CurrentAxes')),h(1));
copyobj(allchild(get(k,'CurrentAxes')),h(2));

% l(1)=legend(h(1),'Decomposition');
% l(2)=legend(h(2),'Share of reallocation');