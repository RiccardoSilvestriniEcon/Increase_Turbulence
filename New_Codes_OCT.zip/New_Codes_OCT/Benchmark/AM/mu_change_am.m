
clear all

load('LT_r.mat')
load('HT_r.mat')

%remove simulations with zeros

LT_HHIr(:,any(LT_HHIr==0))= [];
LT_WADr(:,any(LT_WADr==0))= [];
LT_WAMUr(:,any(LT_WAMUr==0))= [];
LT_PRSr(:,any(LT_PRSr==0))= [];

N=size(HT_HHIr,2);

for r=1:N
     for i=2:120
       ht_dhhi(i,r)= (HT_HHIr(i,r)-HT_HHIr(i-1,r))/HT_HHIr(i-1,r);
       ht_dwad(i,r)= (HT_WADr(i,r)-HT_WADr(i-1,r))/HT_WADr(i-1,r);
       ht_dwamu(i,r)= (HT_WAMUr(i,r)-HT_WAMUr(i-1,r))/HT_WAMUr(i-1,r);
       ht_dwps(i,r)= (HT_PRSr(i,r)-HT_PRSr(i-1,r))/HT_PRSr(i-1,r);
     end
end

NN=size(LT_HHIr,2);

for r=1:NN-1
     for i=2:120
       lt_dhhi(i,r)= (LT_HHIr(i,r)-LT_HHIr(i-1,r))/LT_HHIr(i-1,r);
       lt_dwad(i,r)= (LT_WADr(i,r)-LT_WADr(i-1,r))/LT_WADr(i-1,r);
       lt_dwamu(i,r)= (LT_WAMUr(i,r)-LT_WAMUr(i-1,r))/LT_WAMUr(i-1,r);
       lt_dwps(i,r)= (LT_PRSr(i,r)-LT_PRSr(i-1,r))/LT_PRSr(i-1,r);
     end
end

fin=size(HT_HHIr,1);
for r=1:N
       ht_Dhhi(r)= (HT_HHIr(fin,r)-HT_HHIr(1,r))/HT_HHIr(1,r);
       ht_Dwad(r)= (HT_WADr(fin-1,r)-HT_WADr(1,r))/HT_WADr(1,r);
       ht_Dwamu(r)= (HT_WAMUr(fin,r)-HT_WAMUr(1,r))/HT_WAMUr(1,r);
       ht_Dwps(r)= (HT_PRSr(fin,r)-HT_PRSr(1,r))/HT_PRSr(1,r);
end

fi=size(LT_HHIr,1);

for r=1:NN-1
       lt_Dhhi(r)= (LT_HHIr(fi,r)-LT_HHIr(1,r))/HT_WAMUr(1,r);
       lt_Dwad(r)= (LT_WADr(fi-1,r)-LT_WADr(1,r))/LT_WADr(1,r);
       lt_Dwamu(r)= (LT_WAMUr(fi,r)-LT_WAMUr(1,r))/LT_WAMUr(1,r);
       lt_Dwps(r)= (LT_PRSr(fin,r)-LT_PRSr(1,r))/LT_PRSr(1,r);
end


for r=1:N
    sd_ht_hhi(r)=std(ht_dhhi(:,r));
    sd_ht_wad(r)=std(ht_dwad(:,r));
    sd_ht_wamu(r)=std(ht_dwamu(:,r));
    sd_ht_wps(r)=std(ht_dwps(:,r));
    mn_ht_hhi(r)=mean(ht_dhhi(:,r));
    mn_ht_wad(r)=mean(ht_dwad(:,r));
    mn_ht_wamu(r)=mean(ht_dwamu(:,r));
    mn_ht_wps(r)=mean(ht_dwps(:,r));
end


for r=1:NN-1
    sd_lt_hhi(r)=std(lt_dhhi(:,r));
    sd_lt_wad(r)=std(lt_dwad(:,r));
    sd_lt_wamu(r)=std(lt_dwamu(:,r));
    sd_lt_wps(r)=std(lt_dwps(:,r));
    mn_lt_hhi(r)=mean(lt_dhhi(:,r));
    mn_lt_wad(r)=mean(lt_dwad(:,r));
    mn_lt_wamu(r)=mean(lt_dwamu(:,r));
    mn_lt_wps(r)=mean(lt_dwps(:,r));
end

K=size(HT_WAMUr,1);

 for k=2:K
       med_wamu_ht(k)= median(HT_WAMUr(k,:));
       med_wamu_lt(k)= median(LT_WAMUr(k,:));
 end


Dmed_wamu_ht = (med_wamu_ht(K)-med_wamu_ht(2))/med_wamu_ht(2);
Dmed_wamu_lt = (med_wamu_lt(K)-med_wamu_lt(2))/med_wamu_lt(2);

sdmed_wamu_ht = std(med_wamu_ht);
sdmed_wamu_lt = std(med_wamu_lt);

std_hhi_r=(mean(sd_ht_hhi))/(mean(sd_lt_hhi(r:NN-1)));
std_wad_r=mean(sd_ht_wad)/mean(sd_lt_wad(r:NN-1));
std_wamu_r=mean(sd_ht_wamu)/mean(sd_lt_wamu(r:NN-1));
std_wps_r=mean(sd_ht_wps)/mean(sd_lt_wps(r:NN-1));
mn_hhi_r=(mean(mn_ht_hhi))/(mean(mn_lt_hhi(r:NN-1)));
mn_wad_r=mean(mn_ht_wad)/mean(mn_lt_wad(r:NN-1));
mn_wamu_r=mean(mn_ht_wamu)/mean(mn_lt_wamu(r:NN-1));
mn_wps_r=mean(mn_ht_wps)/mean(mn_lt_wps(r:NN-1));

std_Dhhi_r=(std(ht_Dhhi))/(std(lt_Dhhi));
std_Dwad_r=(std(ht_Dwad))/(std(lt_Dwad));
std_Dwamu_r=(std(ht_Dwamu))/(std(lt_Dwamu));
std_Dwps_r=(std(ht_Dwps))/(std(lt_Dwps));
mn_Dhhi_r=(mean(ht_Dhhi))/(mean(lt_Dhhi));
mn_Dwad_r=(mean(ht_Dwad))/(mean(lt_Dwad));
mn_Dwamu_r=(mean(ht_Dwamu))/(mean(lt_Dwamu));
mn_Dwps_r=(mean(ht_Dwps))/(mean(lt_Dwps));

% %cd 'C:\Users\agama\Dropbox\Turbulence Trends\Codes_SEP2022'\Heterofe_OK\Figures\
% k=hgload('altfe_mureallocation.fig');
% c=hgload('altfe_mudecomposition.fig');
% % Prepare subplots
% figure
% h(1)=subplot(1,2,1);
% h(2)=subplot(1,2,2);
% % Paste figures on the subplots
% copyobj(allchild(get(c,'CurrentAxes')),h(1));
% copyobj(allchild(get(k,'CurrentAxes')),h(2));
% 
% l(1)=legend(h(1),'Decomposition');
% l(2)=legend(h(2),'Share of reallocation');

