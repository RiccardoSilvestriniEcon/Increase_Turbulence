clear all

load HT 

periods_sim=120;

for i=2:periods_sim

a(i-1,1)=(WAMU(i,1)-WAMU(i-1,1))/WAMU(i-1,1);

b(i-1,1)=(REAL(i,1)-REAL(i-1,1))/REAL(i-1,1);

c(i-1,1)=(WTH(i,1)-WTH(i-1,1))/WTH(i-1,1);

d(i-1,1)=(EE(i,1)-EE(i-1,1))/EE(i-1,1);

end

a=mean(a);
b=mean(b);
c=mean(c);
d=mean(d);

xh=[d c b a];

%%

load LT 

for i=2:periods_sim

a(i-1,1)=(WAMU(i,1)-WAMU(i-1,1))/WAMU(i-1,1);

b(i-1,1)=(REAL(i,1)-REAL(i-1,1))/REAL(i-1,1);

c(i-1,1)=(WTH(i,1)-WTH(i-1,1))/WTH(i-1,1);

d(i-1,1)=(EE(i,1)-EE(i-1,1))/EE(i-1,1);

end

a=mean(a);
b=mean(b);
c=mean(c);
d=mean(d);

xh2=[d c b a];

%% plot

yh=[xh2 ; xh];

yh=yh*100*4; %%yearly average change

h=barh(yh);

h(1).FaceColor = [1 1 0];

h(2).FaceColor = [0 1 0];

h(3).FaceColor = [1 0 0];

h(4).FaceColor = [0 0 1];
