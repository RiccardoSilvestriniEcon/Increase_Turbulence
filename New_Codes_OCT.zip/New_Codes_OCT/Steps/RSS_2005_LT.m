%%%%%%%%%%%%%%%%%%%%%%%%%%% Calibration (2005) Low-Turbulence (LT) %%%%%%%%

clear all

%%%%%%%%%%%%%%% Change parameter also below in the function) %%%%%%%%%%%%%%

betta=0.99;   %%%%%%%%%%% Discount factor

theta=10;       %%%%%%%%%% elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

fe=0.1;         %%%%%%%%%%%%%%%%entry costs

load cali_old cali_old

omega0=cali_old(1,13);     %%%%%%%%%%%%%%%% prob entry

omega2=cali_old(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_old(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_old(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_old(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_old(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_old(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_old(1,7);            %%%%%%%%% prob switch to 1

p23=cali_old(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_old(1,10);          %%%%%%%%% prob switch to 1

p32=cali_old(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

load cali_new cali_new

chi=cali_new(1,17);  %%%%%%%%%%%%%%%% from RSS_2005_HT


fun=@equilibrium;

x0=[10,10,10,10,10,10,10,10,10,10];
    
lb=[0,0,0,0,0,0,0,0,0,0];
   
ub=[1000,1000,1000,1000,1000,1000,1000,1000,1000,1000];

options = optimoptions(@lsqnonlin,'MaxFunctionEvaluations',100000,'StepTolerance',1e-18,'FunctionTolerance',1e-18,'MaxIterations',10000);

x=lsqnonlin(fun,x0,lb,ub,options);


M=x(3);

c=x(4);

rho1=x(1);

rho2=x(2);

n1=x(5);

n2=x(6);

n3=x(7);

rho3=((1-n1*rho1^(1-theta)-n2*rho2^(1-theta))/n3)^(1/(1-theta));

e1=x(8);

e2=x(9);

e3=x(10);



N=n1+n2+n3;

ne1=(1-omega2-omega3)*omega0*M;

ne2=omega2*omega0*M;

ne3=omega3*omega0*M;

ne=ne1+ne2+ne3;

nex1=delta1*(ne1+n1);

nex2=delta2*(ne2+n2);

nex3=delta3*(ne3+n3);

nex=nex1+nex2+nex3;

w=x1*rho1*((theta-1)/theta)*(1-rho1^(1-theta));

Y=c;

ll=(w/(c*chi))^phi;

d1=(1/theta-(1/theta-1)*rho1^(1-theta))*rho1^(1-theta)*Y;

d2=(1/theta-(1/theta-1)*rho2^(1-theta))*rho2^(1-theta)*Y;

d3=(1/theta-(1/theta-1)*rho3^(1-theta))*rho3^(1-theta)*Y;

ms1=rho1^(1-theta);

ms2=rho2^(1-theta);

ms3=rho3^(1-theta);

herfindal=(ms1^2)*n1+(ms2^2)*n2+(ms3^2)*n3;

mu1=(((theta-1)/theta)*(1-rho1^(1-theta)))^(-1);

mu2=(((theta-1)/theta)*(1-rho2^(1-theta)))^(-1);

mu3=(((theta-1)/theta)*(1-rho3^(1-theta)))^(-1);

a_mu=(mu1*n1+mu2*n2+mu3*n3)/(n1+n2+n3);

wa_mu=mu1*n1*ms1+mu2*n2*ms2+mu3*n3*ms3;

l1=(rho1^(-theta)*Y)/x1;

l2=(rho2^(-theta)*Y)/x2;

l3=(rho3^(-theta)*Y)/x3;

Lp=l1*n1+l2*n2+l3*n3;

ca_mu=(mu1*n1*l1+mu2*n2*l2+mu3*n3*l3)/Lp;

av_p=(x1*n1+x2*n2+x3*n3)/(n1+n2+n3);

wa_p=x1*n1*ms1+x2*n2*ms2+x3*n3*ms3;

entry_rate=ne/N*100;


%%%%check

y(1)=rho1-(((theta-1)/theta)*(1-rho1^(1-theta)))^(-1)*w/(x1);

y(2)=rho2-(((theta-1)/theta)*(1-rho2^(1-theta)))^(-1)*w/(x2);

y(3)=rho3-(((theta-1)/theta)*(1-rho3^(1-theta)))^(-1)*w/(x3);

y(4)=d1-(1/theta+((theta-1)/theta)*rho1^(1-theta))*rho1^(1-theta)*Y;

y(5)=d2-(1/theta+((theta-1)/theta)*rho2^(1-theta))*rho2^(1-theta)*Y;

y(6)=d3-(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*Y;

y(7)=n1-(1-delta1)*(n1+ne1)*p11-(1-delta2)*(n2+ne2)*p21-(1-delta3)*(n3+ne3)*p31;

y(8)=n2-(1-delta1)*(n1+ne1)*p12-(1-delta2)*(n2+ne2)*p22-(1-delta3)*(n3+ne3)*p32;

y(9)=n3-(1-delta1)*(n1+ne1)*p13-(1-delta2)*(n2+ne2)*p23-(1-delta3)*(n3+ne3)*p33;

y(10)=ne-omega0*M;

y(11)=ne2-omega2*ne;

y(12)=ne3-omega3*ne;

y(13)=ne-ne1-ne2-ne3;

y(14)=fe*w-(1-omega2-omega3)*e1-omega2*e2-omega3*e3;

y(15)=e1-betta*(1-delta1)*(p11*(e1+d1)+p12*(e2+d2)+p13*(e3+d3));

y(16)=e2-betta*(1-delta2)*(p21*(e1+d1)+p22*(e2+d2)+p23*(e3+d3));

y(17)=e3-betta*(1-delta3)*(p31*(e1+d1)+p32*(e2+d2)+p33*(e3+d3));

y(18)=Y-c;

y(19)=c+ne*fe*w-w*ll-d1*n1-d2*n2-d3*n3;

y(20)=1-rho1^(1-theta)*n1-rho2^(1-theta)*n2-rho3^(1-theta)*n3;

y(21)=chi*ll^(1/phi)*c-w;

cali_old=[delta1 delta2 delta3 p11 p12 p13 p21 p22 p23 p31 p32 p33 omega0 omega2 omega3 fe chi];

save cali_old cali_old

clearvars -except M c rho1 rho2 n1 n2 n3 rho3 e1 e2 e3 N ne1 ne2 ne3 ne nex1...
    nex2 nex3 nex w Y ll d1 d2 d3 ms1 ms2 ms3 herfindal mu1 mu2 mu3 a_mu...
    wa_mu l1 l2 l3 Lp ca_mu av_p wa_p entry_rate y;

save SS_final_LT

function F=equilibrium(x)

%%%%%%%%%%%%%%%%%%%%%%%%%%% Calibration OK%%%%%%%%%%%%%%%%%%%%%%%%%

betta=0.99;   %%%%%%%%%%%Discount factor

theta=10;       %%%%%%%%%%elasticity intra sector

x1=1.315;       %%%%%%%%%%%%%%%%%low productivity

x2=4.631;       %%%%%%%%%%%%%%%%%% mid productivity

x3=80.309;         %%%%%%%%%%%%%% high productivity

fe=0.1;         %%%%%%%%%%%%%%%%entry costs

load cali_old cali_old

omega0=cali_old(1,13);     %%%%%%%%%%%%%%%% prob entry

omega2=cali_old(1,14);    %%%%%%%%%%%%%%%% conditional prob mid productivity

omega3=cali_old(1,15);      %%%%%%%%%%%%%%%%%% conditional prob high prod

delta1=cali_old(1,1);      %%%%%%%%%%%%%%% exit rate low productivity

delta2=cali_old(1,2);    %%%%%%%%%%%%%%%%%% exit rate mid productivity

delta3=cali_old(1,3);    %%%%%%%%%%%%%%%%%% exit rate high productivity

p12=cali_old(1,5);            %%%%%%%%%% prob switch to 2

p13=0;            %%%%%%%%%% prob switch to 3

p11=1-p12-p13;           %%%%%%%%%%% prob stay 1

p21=cali_old(1,7);            %%%%%%%%% prob switch to 1

p23=cali_old(1,9);             %%%%%%%%% prob switch to 3

p22=1-p21-p23;          %%%%%%%%%%%% prob stay 2

p31=cali_old(1,10);          %%%%%%%%% prob switch to 1

p32=cali_old(1,11);            %%%%%%%%% prob switch to 2

p33=1-p32-p31;           %%%%%%%%%%%% prob stay 3

phi=1/2;

load cali_new cali_new

chi=cali_new(1,17); %%%%%%%%%%%% from RSS_2015_HT



ne2=omega2*omega0*x(3);

ne3=omega3*omega0*x(3);

ne1=(1-omega2-omega3)*omega0*x(3);

rho3=((1-x(1)^(1-theta)*x(5)-x(2)^(1-theta)*x(6))/x(7))^(1/(1-theta));

ne=omega0*x(3);

w=x1*x(1)*((theta-1)/theta)*(1-x(1)^(1-theta));

d1=(1/theta+((theta-1)/theta)*x(1)^(1-theta))*x(1)^(1-theta)*x(4);

d2=(1/theta+((theta-1)/theta)*x(2)^(1-theta))*x(2)^(1-theta)*x(4);

d3=(1/theta+((theta-1)/theta)*rho3^(1-theta))*rho3^(1-theta)*x(4);

L=(w/(chi*x(4)))^(phi);



F(1)=x(2)*((theta-1)/(theta))*(1-x(2)^(1-theta))-w/x2;

F(2)=rho3*((theta-1)/(theta))*(1-rho3^(1-theta))-w/x3;

F(3)=x(4)+ne*fe*w-w*L-x(5)*d1-x(6)*d2-x(7)*d3;

F(4)=fe*w-(1-omega2-omega3)*x(8)-omega2*x(9)-omega3*x(10);

F(5)=x(5)-(1-delta1)*(x(5)+ne1)*p11-(1-delta2)*(x(6)+ne2)*p21-(1-delta3)*(x(7)+ne3)*p31;

F(6)=x(6)-(1-delta1)*(x(5)+ne1)*p12-(1-delta2)*(x(6)+ne2)*p22-(1-delta3)*(x(7)+ne3)*p32;

F(7)=x(7)-(1-delta1)*(x(5)+ne1)*p13-(1-delta2)*(x(6)+ne2)*p23-(1-delta3)*(x(7)+ne3)*p33;

F(8)=x(8)-betta*(1-delta1)*(p11*(d1+x(8))+p12*(d2+x(9))+p13*(d3+x(10)));

F(9)=x(9)-betta*(1-delta2)*(p21*(d1+x(8))+p22*(d2+x(9))+p23*(d3+x(10)));

F(10)=x(10)-betta*(1-delta3)*(p31*(d1+x(8))+p32*(d2+x(9))+p33*(d3+x(10)));

end
