clear all

%%% Steps

%%%% entry costs

load cali_old cali_old

periods_sim=121;

FE=zeros(periods_sim,1);

%%%%%%%%% Markov

Q11=zeros(periods_sim,1);
Q12=zeros(periods_sim,1);
Q13=zeros(periods_sim,1);
Q21=zeros(periods_sim,1);
Q22=zeros(periods_sim,1);
Q23=zeros(periods_sim,1);
Q31=zeros(periods_sim,1);
Q32=zeros(periods_sim,1);
Q33=zeros(periods_sim,1);

FE(1,1)=0.0572;
        
for i=2:101
    
    FE(i,1)=FE(i-1)+(0.1-0.0572)/100;
    
end

for i=102:periods_sim
    
    FE(i,1)=FE(i-1);
    
end

for i=1:periods_sim
        
        Q11(i,1)=cali_old(1,4);
        
end

for i=1:periods_sim
        
        Q21(i,1)=cali_old(1,7);
        
end
    
for i=1:periods_sim
        
        Q31(i,1)=cali_old(1,10);
        
end
    
for i=1:periods_sim
        
        Q22(i,1)=cali_old(1,8);
        
end
    
for i=1:periods_sim
        
        Q33(i,1)=cali_old(1,12);
        
end

for z=1:periods_sim
    
    Q12(z,1)=1-Q11(z,1);
    
end

for z=1:periods_sim
    
    Q23(z,1)=1-Q21(z,1)-Q22(z,1);
    
end

for z=1:periods_sim
    
    Q32(z,1)=1-Q31(z,1)-Q33(z,1);
    
end

clear cali_old i j k z periods_sim;

save steps_LT.mat;
