clear all

load HT 

periods_sim=120;

a=(WAMU(periods_sim,1)-WAMU(1,1))/WAMU(1,1);

b=(REAL(periods_sim,1)-REAL(1,1))/REAL(1,1);

c=(WTH(periods_sim,1)-WTH(1,1))/WTH(1,1);

d=(EE(periods_sim,1)-EE(1,1))/EE(1,1);

x1=[a b c d];

xh=[d c b a];

load LT 

a=(WAMU(periods_sim,1)-WAMU(1,1))/WAMU(1,1);

b=(REAL(periods_sim,1)-REAL(1,1))/REAL(1,1);

c=(WTH(periods_sim,1)-WTH(1,1))/WTH(1,1);

d=(EE(periods_sim,1)-EE(1,1))/EE(1,1);

x2=[a b c d];

xh2=[d c b a];

y=[x1 ; x2];

y=y*100;

yh=[xh2 ; xh];

yh=yh*100;

b=barh(yh);

b(1).FaceColor = [1 1 0];

b(2).FaceColor = [0 1 0];

b(3).FaceColor = [1 0 0];

b(4).FaceColor = [0 0 1];
