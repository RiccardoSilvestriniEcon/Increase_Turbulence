clear all

load transition_HT

periods_sim=120;

for i=1:periods_sim

    av_profits(i,1)=(N1(i,1)*D1(i,1)+N2(i,1)*D2(i,1)+N3(i,1)*D3(i,1))/(N1(i,1)+N2(i,1)+N3(i,1));
    
end

markup=WAMU;

profits3=D3;

herfindal=HHI;

for j=2:periods_sim
    
    change_p(j,1)=(av_profits(j,1)-av_profits(j-1,1))/av_profits(j-1,1);
    
    change_mu(j,1)=(markup(j,1)-markup(j-1,1))/markup(j-1,1);
    
    change_pw(j,1)=(profits3(j,1)-profits3(j-1,1))/profits3(j-1,1);
 
    change_HHI(j,1)=(herfindal(j,1)-herfindal(j-1,1))/herfindal(j-1,1);    
    
end

av_change_mu_HT=mean(change_mu);

av_change_p_HT=mean(change_p);

av_change_pw_HT=mean(change_pw);

av_change_HHI_HT=mean(change_HHI);

clearvars -except av_change_mu_HT av_change_p_HT av_change_pw_HT av_change_HHI_HT periods_sim

load transition_LT

for i=1:periods_sim

    av_profits(i,1)=(N1(i,1)*D1(i,1)+N2(i,1)*D2(i,1)+N3(i,1)*D3(i,1))/(N1(i,1)+N2(i,1)+N3(i,1));
    
end

markup=WAMU;

profits3=D3;

herfindal=HHI;

for j=2:periods_sim
    
    change_p(j,1)=(av_profits(j,1)-av_profits(j-1,1))/av_profits(j-1,1);
    
    change_mu(j,1)=(markup(j,1)-markup(j-1,1))/markup(j-1,1);
    
    change_pw(j,1)=(profits3(j,1)-profits3(j-1,1))/profits3(j-1,1);
    
    change_HHI(j,1)=(herfindal(j,1)-herfindal(j-1,1))/herfindal(j-1,1);
    
end

av_change_mu_LT=mean(change_mu);

av_change_p_LT=mean(change_p);

av_change_pw_LT=mean(change_pw);

av_change_HHI_LT=mean(change_HHI);

clearvars -except av_change_mu_HT av_change_p_HT av_change_pw_HT av_change_mu_LT av_change_p_LT av_change_pw_LT av_change_HHI_HT av_change_HHI_LT

ratio_mu=av_change_mu_HT/av_change_mu_LT;

ratio_p=av_change_p_HT/av_change_p_LT;

ratio_pw=av_change_pw_HT/av_change_pw_LT;

ratio_HHI=av_change_HHI_HT/av_change_HHI_LT;

clearvars -except ratio_mu ratio_p ratio_pw ratio_HHI

save ratios_SR
