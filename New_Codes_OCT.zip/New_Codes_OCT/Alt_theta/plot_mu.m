clear all

%%%%%%%%% load WA markup for HT

load HT

mu_HT=WAMU;

clearvars -except mu_HT


%%%%%%%%% load WA markup for LT

load LT

mu_LT=WAMU;

clearvars -except mu_HT mu_LT

figure(1)

subplot(1,1,1)
plot(mu_HT,'-k','LineWidth',2)
hold on
plot(mu_LT,'-b','LineWidth',2)
legend('High-Turbulence Sector','Low-Turbulence Sector')
