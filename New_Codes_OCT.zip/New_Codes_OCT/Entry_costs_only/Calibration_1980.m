clear all

%%%%%%%%%%%%%% Riccardo Silvestrini 21/10/2022

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Calibration pre-shock economy, this represent initial
%%%%%%%%%%%%% equilibrium for both low and high turbulence sectors, and final
%%%%%%%%%%%%% equilibrium for low-turbulence sectors.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% calibrate delta3=0.005, in BDS approx 0.006, and assume delta2=
%%%%%%%% delta3, assumption for identification strategy

delta2=0.005;

delta3=0.005;

%%%%%%%% turnover from Philippon, average economy in 1980 0.07 market value,
%%%%%%%% 0.1 operating income

turn=0.1;

%%%%%%%% calibration q21=q31=alpha, equality assumed for identification

alpha=1-(1-turn)^(1/20)/(1-delta2);

alpha2=1-(1-turn)^(1/20); %%%%% only among survivors

check_turnover=1-((1-alpha)*(1-delta2))^20;

check_turnover2=1-(1-alpha2)^20; %%%%% only among survivors

%%%%%%%%%%% find q11, q22 and q33 with q13=0

fun=@test;

x0=[0.9,0.9,0.9,alpha];
    
lb=[0,0,0,alpha];
   
ub=[1,1,1,alpha];

x=lsqnonlin(fun,x0,lb,ub);

q11=x(1);

q12=1-x(1);

q22=x(2);

q23=1-alpha-x(2);

q32=1-alpha-x(3);

q33=x(3);


markov=[q11 q12 0; alpha q22 q23; alpha q32 q33];

test_m=markov^20;

test_ergodic=markov^1000000;


%%%%%%%%%% test 10% business destruction assuming same as Pareto

omega0=0.75;

omega2=0.25333;    

omega3=0.01333;      

delta1=0.03; %%%%%%% calibrated from BDS for small firms

q21=alpha;

q31=alpha;

survival_1=(1-delta1)*(q11*(1-delta1)*(q11*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q12*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3)))+q12*(1-delta2)*(q21*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q22*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3))+q23*(1-delta3)*(q31*(1-delta1)+q32*(1-delta2)+q33*(1-delta3))));

survival_2=(1-delta2)*(q21*(1-delta1)*(q11*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q12*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3)))+q22*(1-delta2)*(q21*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q22*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3))+q23*(1-delta3)*(q31*(1-delta1)+q32*(1-delta2)+q33*(1-delta3)))+q23*(1-delta3)*(q31*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q32*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3))+q33*(1-delta3)*(q31*(1-delta1)+q32*(1-delta2)+q33*(1-delta3))));

survival_3=(1-delta3)*(q31*(1-delta1)*(q11*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q12*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3)))+q32*(1-delta2)*(q21*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q22*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3))+q23*(1-delta3)*(q31*(1-delta1)+q32*(1-delta2)+q33*(1-delta3)))+q33*(1-delta3)*(q31*(1-delta1)*(q11*(1-delta1)+q12*(1-delta2))+q32*(1-delta2)*(q21*(1-delta1)+q22*(1-delta2)+q23*(1-delta3))+q33*(1-delta3)*(q31*(1-delta1)+q32*(1-delta2)+q33*(1-delta3))));

%%%%%%%%%%%%% target approx 0.9 annual

survival=(1-omega2-omega3)*survival_1+omega2*survival_2+omega3*survival_3;

%%%%% test no productivity shocks

surv1=(1-delta1)^4;

surv2=(1-delta2)^4;

surv3=(1-delta3)^4;

surv=(1-omega2-omega3)*surv1+omega2*surv2+omega3*surv3;

%%%%%%%%%%%%%% store for simulation

cali_old=[delta1 delta2 delta3 q11 q12 0 alpha q22 q23 alpha q32 q33 omega0 omega2 omega3];

save cali_old cali_old

Markov=[q11 q12 0; q21 q22 q23; q31 q32 q33];

stationary_approx=Markov^1000000000;

shares_stat=stationary_approx(1,:);

EM=[1 2 3]*transpose(shares_stat);

VARM=shares_stat(1,1)*(1-EM)^2+shares_stat(1,2)*(2-EM)^2+shares_stat(1,3)*(3-EM)^2;

function F=test(x)

%%%%%%%% AC in HT sectors before 1980: 0.79, AC in LT before 1980:
%%%%%%%% 0.79, AC in LT since 1981: lower but statistically indifferent

AC=0.79;

alpha=x(4);        

a11=x(1);

a12=1-x(1);

a13=0;

a21=alpha;

a22=x(2);

a23=1-x(2)-alpha;

a31=alpha;

a32=1-x(3)-alpha;

a33=x(3);


for i=1:19
    
    b11=a11;

    b12=a12;

    b13=a13;

    b21=a21;

    b22=a22;

    b23=a23;
    
    b31=a31;

    b32=a32;

    b33=a33;    
   
    a11=b11*x(1)+b12*alpha+b13*alpha;
    
    a12=b11*(1-x(1))+b12*x(2)+b13*(1-x(3)-alpha);
    
    a13=b11*0+b12*(1-x(2)-alpha)+b13*x(3);
    
    a21=b21*x(1)+b22*alpha+b23*alpha;
    
    a22=b21*(1-x(1))+b22*x(2)+b23*(1-x(3)-alpha);
    
    a23=b21*0+b22*(1-x(2)-alpha)+b23*x(3);    
    
    a31=b31*x(1)+b32*alpha+b33*alpha;
    
    a32=b31*(1-x(1))+b32*x(2)+b33*(1-x(3)-alpha);
    
    a33=b31*0+b32*(1-x(2)-alpha)+b33*x(3);     
    
    
end

F(1)=AC-a11;

F(2)=AC-a22;

F(3)=AC-a33;

F(4)=x(4)-x(4);

end